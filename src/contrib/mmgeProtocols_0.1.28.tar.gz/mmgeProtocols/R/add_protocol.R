#'@export
add_protocol <- function(protocol_name, template = NULL, collection_groups, overwrite = FALSE, ...) {

  values <- list(...)
  values$protocol <- protocol_name

  file_path <- protocol_path(protocol_name)

  if(dir.exists(file_path) & !overwrite) {
    stop("Protocol '", protocol_name, "' already exists.", call. = FALSE)
  }

  dir.create(file_path)

  readme <- glue::glue(
"################################################################################
##
##  PLEASE DO NOT SAVE ANYTHING DIRECTLY TO THIS FOLDER! If you need to save
##  data related to this protocol please put it in the `Data` folder.
##
##  This is the protocol folder for the {protocol_name} protocol. It is meant
##  to be a standard place for data to reside for this protocol. There are
##  settings files in yaml format in the 'Settings' folder. If you know what you
##  are doing you can edit these files to modify how automated scripts
##  interact with this protocol. There is a `Data` folder where external data
##  related to the protocol such as clinical data files should be stored. There
##  is a `Reports` folder where automated reports are saved. Finally, there is a
##  'Scripts' folder where scripts specific to this protocol are housed. If you
##  have any questions about this folder or its contents please contact someone
##  from IT.
##
##  Thanks!
##
################################################################################")

  f <- file(file.path(file_path, "README.txt"))
  writeLines(readme, f)
  close(f)
  mmge::unix2win(file.path(file_path, "README.txt"))

  dir.create(file.path(file_path, "Settings"))
  readme <- glue::glue(
"################################################################################
##
##  This is the Settings folder for the {protocol_name} protocol. It contains
##  configuration files that affect how various automated processes interact
##  with this protocol. These files can be modified if you are comfortable doing
##  so but it is recommended that you contact someone from IT for help the first
##  time.
##
##  Thanks!
##
################################################################################")

  f <- file(file.path(file_path, "Settings", "README.txt"))
  writeLines(readme, f)
  close(f)
  mmge::unix2win(file.path(file_path, "Settings", "README.txt"))

  create_settings_skeleton(file.path(file_path, "Settings"), collection_groups)

  dir.create(file.path(file_path, "Scripts"))
  readme <- glue::glue(
"################################################################################
##
##  This is the Scripts folder for the {protocol_name} protocol. It is meant
##  to be a standard place for scripts specific to this protocol to reside.
##  Generally, files in this folder should only be modified by someone from IT.
##  If you feel there is a reason that you need to modify a file in this folder
##  and you are not from IT please talk to someone from IT first.
##
##  Thanks!
##
################################################################################")

  f <- file(file.path(file_path, "Scripts", "README.txt"))
  writeLines(readme, f)
  close(f)
  mmge::unix2win(file.path(file_path, "Scripts", "README.txt"))

  dir.create(file.path(file_path, "Data"))
  readme <- glue::glue(
"################################################################################
##
##  This is the Data folder for the {protocol_name} protocol. It is meant
##  to be a standard place for data to reside for this protocol. You may put
##  whatever data files you need in this folder. `.xlsx` and `.csv` files can
##  be automatically read by scripts that need to interact with this protocol.
##  If you have any questions about this folder or its contents please contact
##  someone from IT.
##
##  Thanks!
##
################################################################################")

  f <- file(file.path(file_path, "Data", "README.txt"))
  writeLines(readme, f)
  close(f)
  mmge::unix2win(file.path(file_path, "Data", "README.txt"))

  dir.create(file.path(file_path, "Reports"))
  readme <- glue::glue(
"################################################################################
##
##  This is the Reports folder for the {protocol_name} protocol. It is meant
##  to be a standard place automated reports to reside for this protocol. Please
##  don't save any files directly to this folder. If you need to save data
##  related to this protocol please use the `Data` folder in the protocol's
##  root folder. If you have any questions about this folder or its contents
##  please contact someone from IT.
##
##  Thanks!
##
################################################################################")

  f <- file(file.path(file_path, "Reports", "README.txt"))
  writeLines(readme, f)
  close(f)
  mmge::unix2win(file.path(file_path, "Reports", "README.txt"))

}

create_settings_skeleton <- function(protocol, template, values) {

  cg <- as.list(rep(0L, times = length(collection_groups)))
  names(cg) <- collection_groups

  man <- lapply(collection_groups, function(x) {
    c("", "")
  })
  names(man) <- collection_groups

  protocol_name <- basename(gsub(basename(file_path), "", file_path))

  skel <- list(
    protocol = protocol_name,
    email = "@iu.edu",
    manager_email = "@iu.edu",
    aliquot_sizes = cg,
    fuzzy_na_aliquots = TRUE,
    depletion_warning_levels = cg,
    subject_ids = list(
      blinded = "ALTERNATE_MRN",
      clinical = "SUBJECT_LAST_NAME",
      site = "SUBJECT_LAST_NAME"
    ),
    hemoglobin_level =  "case",
    manifest = list(
      default_fields = c(
        "BAR_CODE",
        "<subject_ids$blinded>",
        "SPECIMEN_TYPE",
        "<amount>",
        "<uom>",
        "FINAL_BOX_NO",
        "FINAL_BOX_POSITION"
      ),
      specimen_types = man
    ),
    volume_check = 'none'
  )

  comments <- glue::glue("\n",
                     "####################################################################################\n",
                     "##\n",
                     "##  This is the yaml settings file for the {protocol_name} protocol.\n",
                     "##  It controls how many automated scripts behave when working with this protocol.\n",
                     "##  Please don't edit this unless you know what you are doing. If you need to edit\n",
                     "##  this and don't feel like you don't know what you are doing please contact\n",
                     "##  someone from IT, probably Eric Bailey. Thanks!\n",
                     "##\n",
                     "####################################################################################\n\n")

  y <- paste0(comments, yaml::as.yaml(skel))
  f <- file(file.path(file_path, "settings.yaml"))
  writeLines(y, f)
  close(f)
  mmge::unix2win(file.path(file_path, "settings.yaml"))
  return(invisible(TRUE))

}
