#' get settings for a protocol
#'
#' Reads the settings file for a given protocol
#'
#' @param protocol the name of the protocol
#'
#' @return a list containing the setting for the given protocol
#' @export
#'
#' @examples
#'
#' # Get the settings file for PPMI
#' settings <- get_protocol_settings("MMGE-MJFF-PPMI-BIO")
#'
get_protocol_settings <- function(protocol, settings_file = "settings") {

  protocol <- check_protocol(protocol)

  x <- try(yaml::yaml.load_file(file.path(protocol_path(protocol), "Settings", paste0(settings_file, ".yaml"))))

  if(inherits(x, "try-error")) {
    warning("No protocol setting found for ", protocol)
    x <- list()
  }

  if(settings_file == "settings") {
    class(x) <- c("protocol", class(x))
  }

  return(x)

}

print.protocol <- function(x) {

  cat_line(crayon::silver("<protocol object>"))
  cat_line("Protocol: ", crayon::bold(x$protocol))
  cat_line("Fields:\n", paste("  ", clisymbols::symbol$bullet, " ", names(x), sep = "", collapse = "\n"))
  cat_line("Specimen Types:\n", paste("  ", clisymbols::symbol$bullet, " ", unique(names(x$aliquot_sizes)), sep = "", collapse = "\n"))

  return(x)

}


