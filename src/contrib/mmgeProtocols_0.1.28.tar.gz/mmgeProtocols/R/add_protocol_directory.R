#' add a key to protocol settings files
#'
#' @param directory_name the name of the directory to add
#' @param pattern an optional regular expression to subset the protocols by
#' @param ... additional arguments to pass to \code{\link{grepl}} when subsetting protocols
#'
#' @return \code{TRUE} if successful
#' @export
#'
#' @examples
#' # add an 'API' directory to all MJFF protocols
#' add_protocol_directory('API', pattern = "MJFF", overwrite = TRUE)
add_protocol_directory <- function(directory_name, pattern, ..., overwrite = FALSE) {

  protocols <- get_protocols()

  if(!missing(pattern)) {
    prot
  }


}