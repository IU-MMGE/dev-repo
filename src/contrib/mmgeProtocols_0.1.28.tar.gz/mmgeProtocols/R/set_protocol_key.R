#' add a key to protocol settings files
#'
#' @param key the key to add
#' @param value the value to set for the key
#' @param pattern an optional regular expression to subset the protocols by
#' @param ... additional arguments to pass to \code{\link{grepl}} when subsetting protocols
#' @param overwrite if the key already exists, should it be overwritten?
#'
#' @return \code{TRUE} if successful
#' @export
#'
#' @examples
#' # set the 'create_inventory' key to TRUE for all MJFF protocols
#' set_protocol_key(key = 'create_inventory', value = FALSE, pattern = "MJFF", overwrite = TRUE)
#'
#' # set the PLASMA key under aliquot_sizes to 250 for the PPMI protocol
#' set_protocol_key(key = "aliquot_sizes$PLASMA", value = 250, pattern = "PPMI-BIO", overwrite = TRUE)
set_protocol_key <- function(key, value, pattern, ..., overwrite = FALSE) {

  protocols <- get_protocols()

  if(!missing(pattern)) {
    protocols <- protocols[grepl(pattern, protocols)]
  }

  for(protocol in protocols) {

    settings_file <- file.path(get_setting("protocol_dir"), protocol, "settings.yaml")
    settings <- yaml::yaml.load_file(settings_file)

    k <- strsplit(key, split = "$", fixed = TRUE)[[1]]
    k <- paste0('settings', paste("[['", k, "']]", sep = "", collapse = ""))

    if(!is.null(eval(parse(text = k))) && !overwrite) {
        warning("`", key, "` already exists for protocol `", protocol, "` and overwrite == `FALSE`")
    } else {
      eval(parse(text = paste0(k, " <- ", deparse(value))))
    }

    yaml::write_yaml(settings, file = settings_file)

  }

  return(invisible(TRUE))

}