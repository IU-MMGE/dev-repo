# Builds a data.frame of meta data about the catalog that is used when generating
# the shiny application
catalog_meta <- function(data, config, dictionary) {

  check_dictionary <- function(dictionary, colname, attribute, default) {
    x <- dictionary[[attribute]][dictionary$catalog_id == colname]
    if(length(x) == 0) {
      x <- default
    }
    return(x)
  }

  meta <- as.data.frame(do.call(rbind, lapply(seq(ncol(data)), function(i) {
    colname <- colnames(data)[i]
    c(name = colname,
      index = i,
      type = class(data[[i]]),
      visible = check_dictionary(dictionary, colname, "default", FALSE),
      filterable = check_dictionary(dictionary, colname, "filter", TRUE),
      hidden = check_dictionary(dictionary, colname, "hidden", FALSE),
      filter_type = check_dictionary(dictionary, colname, "filter_type", NA),
      unique = length(unique(data[[i]])),
      decimals = check_decimals(data[[i]])
    )
  })), stringsAsFactors = FALSE)

  for(i in seq(nrow(meta))) {
    if(meta$name[i] %in% dictionary$catalog_id) {
      j <- which(dictionary$catalog_id == meta$name[i])
      if(!is.na(dictionary$type[j])) {
        meta$type[i] <- dictionary$type[j]
      }
    }
  }

  meta$visible <- as.logical(meta$visible)
  meta$index <- as.integer(meta$index)
  meta$filterable <- as.logical(meta$filterable)
  meta$hidden <- as.logical(meta$hidden)
  meta$unique <- as.integer(meta$unique)

  meta$hidden[meta$name == dictionary$catalog_id[dictionary$sample_id]] <- TRUE

  meta$input <- sapply(seq(nrow(meta)), function(r) {

    if(!is.na(meta$filter_type[r])) {
      return(meta$filter_type[r])
    } else if(meta$type[r] == "character") {
      if(meta$unique[r] <= config$display$select_max) {
        return("select")
      } else {
        return("text")
      }
    } else if(meta$type[r] %in% c("numeric", "integer")) {
      if(meta$unique[r] <= config$display$select_max / 2) {
        return("select")
      } else {
        return("slider")
      }
    } else if(meta$type[r] == "Date") {
      return("date")
    } else if(meta$type[r] == "logical") {
      return("checkbox")
    } else {
      return("text")
    }

  })

  return(meta)

}
