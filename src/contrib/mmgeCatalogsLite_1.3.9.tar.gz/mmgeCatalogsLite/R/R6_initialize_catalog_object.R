# `protocol` determines the folder where config files are looked for. `.protocol` determines what protocol is filtered on in OnCore/Tesla if it is different
R6_initialize_catalog_object <- function(catalog_dir = ".",
                                         env = get_env(),
                                         .protocol = NULL, .catalog_name = NULL) {

  if(!is.null(.protocol)) {
    catalog_dir <- file.path(getOption("catalog_dir"), .protocol)
    self$protocol <- .protocol
    if(!is.null(.catalog_name)) {
      self$catalog_name <- .catalog_name
      catalog_dir <- file.path(catalog_dir, "Catalogs", .catalog_name)
    } else {
      catalog_dir <- file.path(catalog_dir, "Catalogs")
    }
  }

  self$catalog_dir <- normalizePath(catalog_dir)

  if(!dir.exists(self$catalog_dir)) {
    stop(self$catalog_dir, " does not exist.", call. = FALSE)
  }

  if('config.yaml' %in% list.files(self$catalog_dir)) {
    config <- yaml::yaml.load_file(file.path(self$catalog_dir, "config.yaml"))
  } else {
    stop(self$catalog_dir, " is not an mmgeCatalogsLite-compatible directory.", call. = FALSE)
  }

  self$env <- get_env()
  if(!self$env %in% c("PRD", "DEV", "STG")) {
    warning("Invalid `env` argument: ", self$env, "\n - Defaulting to `PRD`")
    self$env <- 'PRD'
  }

  if(is.null(self$protocol)) {
    self$protocol <- config$protocol
  }
  if(is.null(self$catalog_name)) {
    self$catalog_name <- config$short_name
  } else if(self$catalog_name != config$short_name) {
    stop("`catalog_name` must match `short_name` in the config.yaml", call. = FALSE)
  }
  self$protocol_dir <- self$catalog_dir

  self$get()

  message(glue::glue("mmgeCatalog object created for {self$catalog_name} in {self$protocol[1]}."))

  return(invisible(self))

}