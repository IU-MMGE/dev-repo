#'@import shiny
#'@import shinydashboard
#'@import shinyBS2
#'@importFrom magrittr '%>%'
#'@export
magrittr::`%>%`

#'@importFrom rlang '.data'
#'@export
rlang::.data

#'@importFrom rlang ':='
#'@export
rlang::`:=`

.onLoad <- function(...) {
  # Create link to javascript and css files for package
  shiny::addResourcePath("mmgeCatalogs", system.file("www", package="mmgeCatalogsLite"))
}

mmgeCatalogsDep <- htmltools::htmlDependency(
  "mmgeCatalogs",
  packageVersion("mmgeCatalogsLite"),
  src = c(href = "mmgeCatalogs"),
  stylesheet = c(
    "css/mmgeCatalogs.css",
    "css/bootstrap-tour.css"
  ),
  script = c(
    "js/catalog_misc.js",
    "js/mmgeCatalog.js",
    "js/mmgeTable.js",
    "js/mmgeControl.js",
    "js/images.js",
    "js/magnify.js"
  )
  # script = c(
  #   "js/bootstrap-tour.js",
  #   "js/tour.js",
  #   "js/magnify.js",
  #   "js/mmgeCatalog_class.js",
  #   "js/catalogSelections_class.js",
  #   "js/catalogControl_class.js",
  #   "js/mmgeCatalogs2.js"
  # )
)

#'@export
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

check_decimals <- function(x) {
  unname(ceiling(quantile(sapply(strsplit(as.character(x), ".", fixed = TRUE), function(w) {
    if(length(w) == 2) {
      nchar(w[2])
    } else {
      0
    }
  }), 0.90)))
}

as.image <- Vectorize(function(x) {
  l <- jsonlite::toJSON(x)
  as.character(tags$button(class = "btn btn-default", role = "button", tags$i(class = "fas fa-image"), "View Image", onclick = glue::glue("showImages(event, {l})")))
})

as.link <- Vectorize(function(x) {
  as.character(tags$a(href = x$url, x$label))
})

dictInfo <- function(field_name, dictionary, data, config, meta) {

  dict <- dictionary[dictionary$catalog_id == field_name, ]
  return(as.character(tags$table(class = 'table',
    tags$tbody(
      tags$tr(tags$td(colspan = 2, dict$description)),
      tags$tr(tags$td("Data Type"), tags$td(meta$type[meta$name == field_name])),
      tags$tr(tags$td("Unique Values"), tags$td(meta$unique[meta$name == field_name]))
    )
  )))

}