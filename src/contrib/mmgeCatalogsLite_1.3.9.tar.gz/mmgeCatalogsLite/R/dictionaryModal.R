# Builds the dictionary modal for the shiny application
dictionaryModal <- function() {

  tags$div(class = "modal fade", id = "dataDictionaryModal", tabindex = "-1", role = "dialog",
           tags$div(class = "modal-dialog modal-lg", role = "document",
                    tags$div(class = "modal-content",
                             tags$div(class = "modal-header",
                                      tags$button(type = "button", class = "close", `data-dismiss` = "modal", HTML("&times;")),
                                      tags$h4(class = "modal-title", icon("book", class = "fa-fw fa-lg"),  "Data Dictionary")
                             ),
                             tags$div(class = "modal-body",
                                      tableOutput("dataDictionary"),
                                      tags$script("$(document).ready(function() {$('[data-toggle=\"popover\"]').popover()})")
                             ),
                             tags$div(class = "modal-footer",
                                      tags$button(type="button", class="btn btn-default", `data-dismiss`="modal", "Close")
                             )
                    )
           )
  )

}