# Builds the UI for the help modal
R6_helpModal <- function(config) {

  tags$div(class = "modal fade", id = "helpModal", tabindex = "-1", role = "dialog",
           tags$div(class = "modal-dialog modal-lg", role = "document",
                    tags$div(class = "modal-content",
                             tags$div(class = "modal-header",
                                      tags$h4(class = "modal-title", style = "display: inline-block", icon("question-circle", class = "fa-fw fa-lg"), "Help"),
                                      tags$ul(class = "nav nav-tabs pull-right help-nav",
                                              tags$li(class = "active", tags$a(href = "javascript:;", `data-target` = "#generalHelp", class = "help-tab", "General")),
                                              if(config$display$allow_filters) {
                                                tags$li(tags$a(href = "javascript:;", `data-target` = "#filteringHelp", class = "help-tab", "Filtering"))
                                              },
                                              if(config$display$allow_joins) {
                                                tags$li(tags$a(href = "javascript:;", `data-target` = "#joiningHelp", class = "help-tab", "Joining"))
                                              },
                                              if(config$display$allow_orders) {
                                                tags$li(tags$a(href = "javascript:;", `data-target` = "#orderingHelp", class = "help-tab", "Ordering"))
                                              }
                                      )
                             ),
                             tags$div(class = "modal-body",
                                      R6_helpPage("general", config, shown = TRUE),
                                      R6_helpPage("filtering", config),
                                      R6_helpPage("joining", config),
                                      R6_helpPage("ordering", config)
                             ),
                             tags$div(class = "modal-footer",
                                      tags$button(type="button", class="btn btn-default", `data-dismiss`="modal", "Close")
                             )
                    )
           )
  )

}