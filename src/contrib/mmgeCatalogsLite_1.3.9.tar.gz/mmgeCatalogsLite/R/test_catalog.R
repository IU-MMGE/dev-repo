
#'@export
test_catalog <- function(catalog_dir, protocol, catalog_name = NULL, debug = FALSE) {

  if(!missing(catalog_dir)) {
    catalog <- mmgeCatalog$new(catalog_dir)
  } else if(!missing(protocol)) {
    catalog <- mmgeCatalog$new(.protocol = protocol, .catalog_name = catalog_name)
  } else {
     stop("You must provide a catalog directory or a protocol to test run a catalog.", call. = FALSE)
  }
  if(debug) {
    debug(catalog$display)
  }
  catalog$display()

}

dummy_join_data <- function(catalog, size = 1) {

  words <- c("Dog", "Cat", "Mouse", "Flea", "Yersinia pestis")

  if(size > 1) size = 1
  if(size <= 0) size = 1

  x <- catalog$catalog
  y <- x[, "SUBJECT_ID", drop = FALSE]
  y$TEST_SEQ <- seq(nrow(y))
  y$TEST_CAT <- sample(words, size = nrow(y), replace = TRUE)
  y$TEST_STR <- sapply(nrow(y),
    function(i) {
      paste(
        paste(
          sample(c(LETTERS, letters, 0:9), 4, replace = TRUE),
          collapse = ""),
        "-",
        paste(
          sample(c(LETTERS, letters, 0:9), 10, replace = TRUE),
          collapse = ""),
        sep = ""
      )
    })

  y <- y[sample.int(nrow(y), size = floor(nrow(y)*size)), ]

}