catalogPage <- function (header, sidebar, body, title = NULL,
                         skin = c("blue", "black", "purple", "green", "red",
                                  "yellow")) {

  skin <- match.arg(skin)
  extractTitle <- function(header) {
    x <- header$children[[2]]
    if (x$name == "span" && !is.null(x$attribs$class) &&
        x$attribs$class == "logo" && length(x$children) !=
        0) {
      x$children[[1]]
    }
    else {
      ""
    }
  }
  title <- title %OR% extractTitle(header)
  content <- div(class = "wrapper", header, sidebar, body)
  collapsed <- findAttribute(sidebar, "data-collapsed", "true")
  shinydashboard:::addDeps(tags$body(class = paste0("skin-", skin, if (collapsed)
    " sidebar-collapse"), style = "min-height: 611px;",
    shiny::bootstrapPage(content, title = title)))
}