R6_catalog_ui <- function(private) {

  if(!dir.exists(self$catalog_dir)) {
    self$catalog_dir <- getwd()
  }

  settings <- try(jsonlite::fromJSON(mmgeMongo::mongo_connection("mmgeCatalogs", collection = collection('settings', self = self))$iterate()$json()))

  if(!inherits(settings, 'try-error')) {
    color <- settings$catalog_color
  } else {
    color <- "blue"
  }

  shinydashboard::dashboardPage(skin = color,
                                title = private$config_obj$name,
                                private$catalogHeader(),
                                private$catalogSidebar(),
                                private$catalogBody())

}