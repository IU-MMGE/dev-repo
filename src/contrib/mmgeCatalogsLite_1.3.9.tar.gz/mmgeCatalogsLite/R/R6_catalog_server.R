R6_catalog_server <-  function(input, output, session) {

  logger <- function(event, msg = "", level = 'info') {
    try(self$log(user = values$user$uid, event = event, msg = msg, level = level), silent = TRUE)
  }

  values <- reactiveValues(
    data = private$catalog_obj,
    config = private$config_obj,
    dictionary = private$dictionary_obj,
    user = NULL,
    settings_collection = collection(name = 'settings', self = self),
    settings = NULL
  )

  filteredSpecimens <- eventReactive(input$catalogTable_rows_all, {
    i <- input$catalogTable_rows_all
    ids <- paste0("#", data()$SAMPLE_ID[i])
  })

  observeEvent(filteredSpecimens(), {
    session$sendCustomMessage(type = "allCurrentRows", message = filteredSpecimens());
  })

##### User Display #####
  observe({
    if(is.null(session$user)) {
      if(get_env() == "DEV") {
        values$user <- mmgeLDAP::user_lookup('eb11307')
      } else {
        stop("Invalid user state...")
      }
    } else {
      values$user <- mmgeLDAP::user_lookup(session$user)
    }
  })

  output$user <- shiny::renderText({
    logger("User Login")
    name <- session$user
    try({name <- paste0(values$user$first_name, " ", values$user$last_name, " (", values$user$uid, ")")})
    return(name)
  })

##### Catalog Data Processing #####

  data <- shiny::reactive({
    req(values$data)
    req(values$dictionary)
    req(values$config)

    data <- values$data
    config <- values$config
    rownames(data) <- data[[values$dictionary$catalog_id[values$dictionary$sample_id]]]
    for(i in seq(nrow(values$dictionary))) {
      if(!is.na(values$dictionary$type[i])) {
        fn <- switch(values$dictionary$type[[i]],
                     character = as.character,
                     numeric = as.numeric,
                     integer = as.integer,
                     date = as.Date,
                     image = as.image,
                     link = as.link,
                     {stop("Unrecognized column type: ", config$display$column_type_override[i])}
        )
        data[[values$dictionary$catalog_id[i]]] <- fn(data[[values$dictionary$catalog_id[i]]])
      }
    }

    return(data)

  })

  download_data <- shiny::reactive({

    data <- data()

    for(c in seq(ncol(data))) {

      if(any(grepl("<.*?>", data[[c]]))) {
        x <- sapply(regmatches(data[[c]], regexec(">(.*?)<", data[[c]])), function(y) y[2])
        #x <- sapply(regmatches(data[[c]], regexec("href = '(.*?)'", data[[c]])), function(y) y[2])
        x[is.na(x)] <- ""
        data[[c]] <- x
      }

    }

    return(data)

  })

  catalog_metadata <- reactive({
    catalog_meta(data(), values$config, values$dictionary)
  })

  output$menu <- renderMenu({

    req(values$settings)

    data <- data()
    config <- values$config
    meta <- catalog_metadata()
    meta <- meta[!meta$hidden, ]

    if(values$settings$enabled) {

      controls <- lapply(seq(nrow(meta)), function(i) {

        R6_columnControl(meta$name[i],
                      type = meta$input[i],
                      visible = meta$visible[i],
                      filterable = meta$filterable[i] & config$display$allow_filters,
                      column_data = data[[meta$name[i]]]
        )

      })

    } else {
      controls <- list()
    }

    controls[[length(controls) + 1]] <- tags$div(style="height: 100px;")

    return(sidebarMenu(tagList(controls)))

  })

  output$catalogTable <- DT::renderDataTable({

    req(values$settings)
    config <- values$config
    meta <- catalog_metadata()
    if(values$settings$enabled) {
      data <- data()
#      data <- cbind(DT_RowId = paste0("row_", data$SAMPLE_ID), data)
      cd <- lapply(seq(ncol(data)), function(i) {
        list(
          targets = i,
          name = colnames(data)[i],
          visible = meta$visible[meta$name == colnames(data)[i]] & !meta$hidden[meta$name == colnames(data)[i]]
        )
      })
    } else {
      data <- data.frame()
      cd <- list()
    }
    ajax_url <- DT::dataTableAjax(session, data, rownames = TRUE, filter = mmgeFilter)

    DT::datatable(data = data, escape = FALSE, rownames = TRUE, class = "display compact cell-border",
                  extensions = c('Select', 'Scroller'),
                  options = list(
                    initComplete = DT::JS("mmgeCatalog.initComplete"),
                    drawCallback = DT::JS("mmgeCatalog.drawCallback"),
                    select = list(style = "os", items = 'row'),
                    dom = 't',
                    columnDefs = cd,
                    deferRender = TRUE,
                    stateSave = TRUE,
                    scrollY = "100px",
                    scrollX = TRUE,
                    rowId = "0",
                    scroller = TRUE,
                    serverSide = TRUE,
                    ajax = list(url = ajax_url)
                  ),
                  selection = 'none')

  })

  # output$footer <- renderText({
  #   x = input$sw
  #   sprintf("filter: %s\nremove_missing: %s\nfilter_type: %s\nfilter_visible: %s\ncolumn_visible: %s", x$filter, x$remove_missing, x$filter_type, x$filter_visible, x$column_visible)
  # })

  observeEvent(input$selectNone, {
    session$sendCustomMessage(type = "update_selected_rows", message = NA);
  })

  observeEvent(input$selectAll, {
    selected <- paste0("#", rownames(data())[input$catalogTable_rows_all])
    session$sendCustomMessage(type = "update_selected_rows", message = selected)
  })

  observeEvent(input$selectInverse, {
    selected <- paste0("#", rownames(data())[!(rownames(data()) %in% input$selected_rows)])
    session$sendCustomMessage(type = "update_selected_rows", message = selected)
  })

  output$dataDictionary <- renderTable(
    {
      # dict <<- values$dictionary
      # data <- data()
      # dddd <<- data
      # conf <<- values$config
      # sett <<- values$settings
      # meta <<- catalog_metadata()
#
#       infoBtn = Vectorize(function(field_name) {
#
#         content <- dictInfo(field_name, values$dictionary, data(), values$config, catalog_metadata())
#         print(content)
#         as.character(tags$i(
#           title = field_name,
#           class = 'fa fa-fw fa-info',
#           `data-trigger` = "hover",
#           `data-toggle` = 'popover',
#           `data-html` = 'true',
#           `data-sanitize` = 'false',
#           `data-content` = content))
#
#       })

      x <- values$dictionary %>%
             dplyr::filter(include == TRUE) %>%
#             dplyr::mutate(info = infoBtn(catalog_id)) %>%
             dplyr::select("Column" = catalog_id, "Description" = description)
      x
    }, width = "100%",
    hover = TRUE,
    striped = TRUE,
    bordered = TRUE,
    spacing = "xs",
    sanitize.text.function = function(x) x
  )

  observeEvent(input$file_upload, {
    req(values$settings)
    if(values$settings$enabled == TRUE) {

      catalog <- values$data

      msg <- ""
      success <- 0

      files <- c()

      join_fields <- values$dictionary$catalog_id[values$dictionary$join]

      if(nrow(input$file_upload) >= 1) {

        for(r in seq(1, nrow(input$file_upload))) {

          files <- c(files, input$file_upload$name[r])
          tf <- processJoin(input$file_upload$name[r], input$file_upload$datapath[r], config = values$config)

          if(!is.null(tf)) {

            jf <- join_fields[join_fields %in% colnames(tf)]

            for(i in seq_along(jf)) {
              tf[[jf[i]]] <- as.character(tf[[jf[i]]])
              catalog[[jf[i]]] <- as.character(catalog[[jf[i]]])
            }

            if(length(jf) > 0) {
              tryCatch({
                catalog <- catalog %>%
                  dplyr::left_join(tf, by = jf)
              },
              warning = function(w) {
                logger("External Data Join", level = 'warning', msg = w$message[1])
              },
              error = function(e) {
                logger("External Data Join", level = 'error', msg = e$message[1])
              })

              msg <- paste0(msg, "<p>Joining ", input$file_upload$name[r], " by ", paste(jf, collapse = ", "), "</p>")

              success <- success + 1

            } else {

              msg <- paste0(msg, "<p>No valid join fields found in ", input$file_upload$name[r], "... Skipping file.")

            }

          } else {
            msg <- paste0(msg, "<p>Do not know how to read ", input$file_upload$name[r], "... Skipping file.")
          }

        }

      }

      values$data <- catalog

      if(success == nrow(input$file_upload)) {
        style = "success"
        title = "All files joined"
        icon = "thumbs-up"
        logger("External Data Join", msg = glue::glue("{success}/{nrow(input$file_upload)} files joined"))
      } else if(success == 0) {
        style = "danger"
        title = "Unable to join files"
        icon = "exclamation-triangle"
      } else {
        style = "warning"
        title = "Some files couldn't be joined"
        icon = "exclamation-circle"
      }

      shinyBS2::createAlert(session, "join_info", alertId = "joinAlert", style = style, title = title, content = msg)

    }

    session$sendCustomMessage(type = "disableFileUpload", message = list(name = "file_upload"))

  })

  output$download_all <- downloadHandler(
    filename = function() {

      ts <- format(Sys.time(), format = "%Y-%m-%d_%H%M%S")
      return(gsub(" ", "_", paste0(values$config$name, "_", ts, ".csv")))

    },
    content = function(file) {
      req(values$settings)
      if(values$settings$enabled) {
        f <- download_data()
      } else {
        f <- data.frame()
      }

      tryCatch({
        write.csv(f, file, row.names = FALSE)
        logger("Full Catalog Download", level = 'info', msg = glue::glue("Full Catalog Downloaded"))
      },
      warning = function(w) {
        logger("Full Catalog Download", level = 'warning', msg = w$message[1])
      },
      error = function(e) {
        logger("Full Catalog Download", level = 'error', msg = e$message[1])
      })

    }
  )

  output$download_filtered <- downloadHandler(
    filename = function() {

      ts <- format(Sys.time(), format = "%Y-%m-%d_%H%M%S")
      return(gsub(" ", "_", paste0(values$config$name, "_Request_Filtered_", ts, ".csv")))

    },
    content = function(file) {
      req(values$settings)
      if(values$settings$enabled) {
        f <- download_data()
        f <- f[input$catalogTable_rows_all, ]
      } else {
        f <- data.frame()
      }

      tryCatch({
        write.csv(f, file, row.names = FALSE)
        logger("Filtered Catalog Download", level = 'info', msg = glue::glue("Full Catalog Downloaded"))
      },
      warning = function(w) {
        logger("Filtered Catalog Download", level = 'warning', msg = w$message[1])
      },
      error = function(e) {
        logger("Filtered Catalog Download", level = 'error', msg = e$message[1])
      })

    }
  )

  output$download_selected <- downloadHandler(
    filename = function() {

      ts <- format(Sys.time(), format = "%Y-%m-%d_%H%M%S")
      return(gsub(" ", "_", paste0(values$config$name, "_Request_Selected_", ts, ".csv")))

    },
    content = function(file) {
      req(values$settings)
      if(values$settings$enabled) {
        f <- download_data()
        f <- f[rownames(f) %in% gsub("^#", "", input$selected_rows), ]
      } else {
        f <- data.frame()
      }

      tryCatch({
        write.csv(f, file, row.names = FALSE)
        logger("Selected Catalog Download", level = 'info', msg = glue::glue("Full Catalog Downloaded"))
      },
      warning = function(w) {
        logger("Selected Catalog Download", level = 'warning', msg = w$message[1])
      },
      error = function(e) {
        logger("Selected Catalog Download", level = 'error', msg = e$message[1])
      })

    }
  )

  observeEvent(input$column_removal, {
    values$data <- values$data[,colnames(values$data) != input$column_removal]
  })

  observe({

    user = values$user$uid

    x <- function(uid) {

      function(session) {
        session$onSessionEnded(function() {
          self$log(user = uid, event = "Session Ended", msg = "")
        })
      }

    }

    y <- x(user)

    y(session)

  })


  internal_user <- reactive({
    internal_groups = c("Administrators", "Managers", "Coordinators", "Specialists", "Faculty", "Students", "Internal")
    return(any(values$user$groups %in% internal_groups))
  })

  output$internalUser <- reactive({
    internal_user()
  })
  outputOptions(output, "internalUser", suspendWhenHidden = FALSE)

###### Logs ######

  logs <- reactive({
    req(internal_user())
    if(internal_user()) {
      logs <- mmgeMongo::mongo_query("mmgeCatalogs", "logs",
                                     query = glue::glue('{{"protocol": "{self$protocol[1]}", "catalog": "{self$catalog_name}"}}'),
                                     fields = c("level", "user", "event", "message", "timestamp"))
      for(col in colnames(logs)) {
        logs[[col]] <- unlist(logs[[col]])
      }
      return(logs)
    } else {
      return(data.frame())
    }
  })

  output$logs_download <- downloadHandler(
    filename = function() {

      ts <- format(Sys.time(), format = "%Y-%m-%d_%H%M%S")
      return(gsub(" ", "_", paste0(values$config$name, "_logs_", ts, ".csv")))

    },
    content = function(file) {

      f <- logs()

      tryCatch({
        write.csv(f, file, row.names = FALSE)
        logger("Logs Download", level = 'info', msg = glue::glue("Full Catalog Downloaded"))
      },
      warning = function(w) {
        logger("Logs Download", level = 'warning', msg = w$message[1])
      },
      error = function(e) {
        logger("Logs Download", level = 'error', msg = e$message[1])
      })

    }
  )

  output$logsTable <-  DT::renderDataTable({

    logs <- logs()

    DT::datatable(data = logs, rownames = FALSE, class = "display compact cell-border",
                  extensions = c('Scroller'),
                  options = list(
                    deferRender = TRUE,
                    stateSave = FALSE,
                    scrollY = "500px",
                    scrollX = TRUE,
                    scroller = TRUE,
                    serverSide = TRUE
                  ))

  })

###### Settings Controls ######

  output$disabled_message <- renderText({
    values$settings$disabled_message
  })

  #Makes settings available to conditional panels... I think
  output$settings <- reactive({
    values$settings
  })
  outputOptions(output, "settings", suspendWhenHidden = FALSE)

  output$enabled <- reactive({
    values$settings$enabled
  })
  outputOptions(output, "enabled", suspendWhenHidden = FALSE)

  output$draft <- reactive({
    values$settings$draft
  })
  outputOptions(output, "draft", suspendWhenHidden = FALSE)

  # Renders the settings controls when an internal user is logged in.
  output$settings_controls <- renderUI({
    req(internal_user(), values$settings)
    if(internal_user()) {
      settings <- values$settings
      tags$form(
        checkboxInput("enable_catalog", "Enable Catalog", value = settings$enabled),
        conditionalPanel('input.enable_catalog==false',
          textInput("disabled_message", label = "Disabled Message", value = settings$disabled_message, width = "100%")
        ),
        selectInput("catalog_color", "Header Color", choices = c("blue", "black", "purple", "green", "red", "yellow"), selected = settings$catalog_color),
        checkboxInput("draft_mode", "Show Draft Watermark", value = settings$draft),
        checkboxInput("show_alert_message", "Show Alert Message", value = settings$alert_settings$show),
        conditionalPanel('input.show_alert_message==true',
          wellPanel(
            selectInput('alert_style', label = "Alert Style", choices = c("info", "success", "warning", "danger"), width = "100%", selected = settings$alert_settings$style),
            textInput('alert_title', label = "Alert Title", width = "100%", value = settings$alert_settings$title),
            textInput('alert_message', label = "Alert Message", width = "100%", value = settings$alert_settings$message),
            dateInput("alert_expires", label = "Alert Expiration", width = "100%", value = settings$alert_settings$expires)
          )
        )
      )
    } else {
      "Why are you looking at the source code? If you have questions please contact us."
    }
  })

  # Should save settings to mongo anytime they are changed
  shiny::observeEvent(values$settings, {
    req(internal_user())
    if(internal_user()) {
      m <- mmgeMongo::mongo_connection("mmgeCatalogs", values$settings_collection)
      m$drop()
      m$insert(values$settings)
      m$disconnect()
      session$sendCustomMessage(type = "updateCatalogColor", message = values$settings$catalog_color);
    }
  })

  #Loads settings initially or assigns default values if no settings are found
  shiny::observe({

#    req(internal_user())
    req(values$settings_collection)

    default_settings <- list(
      enabled = TRUE,
      disabled_message = "This catalog has been disabled. Please contact study staff if you have questions.",
      draft = TRUE,
      catalog_color = 'red',
      alert_settings = list(
        show = FALSE,
        style = 'info',
        title = "Alert Title",
        message = "This is an alert message.",
        expires = "2099-01-01",
        id = "xxxxx"
      )
    )

    m <- mmgeMongo::mongo_connection("mmgeCatalogs", values$settings_collection)
    settings <- try(jsonlite::fromJSON(m$iterate()$json()), silent = TRUE)
    if(inherits(settings, 'try-error')) {
      settings <- default_settings
    } else {
      # Should add any new settings that had been added since the last time the
      # catalog was loaded
      if(any(!names(default_settings) %in% names(settings))) {
        settings <- utils::modifyList(default_settings, settings)
      }
      # Should remove any old settings that aren't used anymore
      settings[!names(settings) %in% names(default_settings)] <- NULL
    }
    if(settings$alert_settings$show == TRUE) {
      session$sendCustomMessage(type = "display_alert", message = settings$alert_settings);
    }
    values$settings <- settings
  })

  #Saves settings when `Save Settings` button is clicked in modal
  shiny::observeEvent(input$settings_save, {

    settings <- values$settings
    settings$draft <- input$draft_mode
    settings$disabled_message <- input$disabled_message
    settings$enabled <- input$enable_catalog
    settings$catalog_color <- input$catalog_color
    settings$alert_settings$show <- input$show_alert_message
    settings$alert_settings$style <- input$alert_style
    settings$alert_settings$title <- input$alert_title
    settings$alert_settings$message <- input$alert_message
    settings$alert_settings$expires <- input$alert_expires
    settings$alert_settings$id <- hashids::encode(as.numeric(charToRaw(paste(input$alert_title, input$alert_message))), settings = hashids::hashid_settings(self$protocol[1]))
    values$settings <- settings

  })


###### Images Modal #####

}
