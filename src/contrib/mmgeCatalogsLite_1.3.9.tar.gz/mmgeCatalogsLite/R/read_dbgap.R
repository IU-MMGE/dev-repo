#' read dbGaP data from a text file
#'
#' Reads the text files imported from dbGaP.
#'
#' @param fn The path to the file to read
#'
#' @export
read_dbgap <- function(fn) {

  dead_column <- function(x) {
    y <- unique(x)
    if(length(y) == 1) {
      if(any(is.na(y), y == "")) {
        return(TRUE)
      }
    }
    return(FALSE)
  }
  x <- readLines(fn)
  x <- x[!grepl("^#", x)]
  x <- x[x != ""]
  headers <- strsplit(x[1], "\t")[[1]]
  x <- data.table::fread(paste(x[2:length(x)], collapse = "\n"),colClasses = "character", header = FALSE, data.table = FALSE)
  while(dead_column(x[,ncol(x)])) {
    x <- x[, -ncol(x)]
  }
  if(ncol(x) != length(headers)) {
    return(NULL)
  }
  colnames(x) <- headers
  if("SECTION" %in% headers) {
    section = unique(x$SECTION)
    if(length(section) == 1) {
      x <- x[, colnames(x) != "SECTION"]
      colnames(x) <- sapply(colnames(x), function(cn) {
        if(!cn %in% c("SUBJID", "EVENT")) {
          sprintf("%s_%s", section, cn)
        } else {
          cn
        }
      })
    }
  }

  for(i in seq(ncol(x))) {

    v <- x[, i]
    v[v == ""] <- NA
    v2 <- suppressWarnings(as.numeric(v))
    if(sum(is.na(v2)) == sum(is.na(v))) {
      x[, i] <- v2
    }

  }

  return(x)

}
