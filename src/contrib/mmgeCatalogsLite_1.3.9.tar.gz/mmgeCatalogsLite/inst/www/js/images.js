function showImages(event, data) {

  $("#imageModal").modal("show");

  $("#imageThumbnails").empty();
  data = JSON.parse(data);
  let subject_id = data.record[data.attributes.subject_id];
  $("#imageTitle").html("Subject: " + subject_id);
  let images = data.images;
  if(!Array.isArray(images)) images = [images];
  images.forEach(function(img) {
    $("<img src = 'images/" + img + "' class = 'img-thumbnail specimen-image' style = 'width: 100%; cursor: pointer;' onClick = 'setImage(this, \"" + img + "\")' />").appendTo("#imageThumbnails");
  });
  $("#imageThumbnails img:first-child").addClass("selected");
  setImage(null, images[0]);
  $("#imageInfo").html(makeImageTable(data.record));

}

function makeImageTable(record) {
  let tbl = $("<table class='table table-condensed'>");
  tbl.append("<thead><tr><th>Field</th><th>Value</th></tr></thead>");
  tbl.append("<tbody>");
  let body = tbl.find("tbody");
  for(let i = 0; i < Object.keys(record).length; i++) {
    let f = Object.keys(record)[i];
    let v = record[f];
    body.append("<tr><td>" + f + "</td><td>" + v + "</td></tr>");
  }
  return tbl;
}

function showImageInfo(event) {
  if($("#imageInfo").css('display') === "none") {
    $("#imageFullSizeCol").removeClass("col-sm-10").addClass("col-sm-6");
    $("#imageInfo").css("display", "block");
  } else {
    $("#imageFullSizeCol").removeClass("col-sm-6").addClass("col-sm-10");
    $("#imageInfo").css("display", "none");
  }
}

function setImage(thumbnail, img) {
  $("#imageThumbnails img").removeClass("selected");
  $(thumbnail).addClass("selected");
  $("#imageFullSize").attr("src", "images/" + img);
  $("#imageFullSize").magnify();
}