class mmgeImages {

  constructor() {

  }

}
