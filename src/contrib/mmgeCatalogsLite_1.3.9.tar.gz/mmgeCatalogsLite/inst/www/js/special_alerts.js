
$(document).ready(function() {

  $("section.content").prepend("<div id = 'special-alerts'></div>");

  Shiny.addCustomMessageHandler("display_alert", function(special_alert) {
    if(special_alert !== undefined) {
      let alert = special_alert;
      let id = alert.id;
      let dismissed = getCookieValue(alert.id + "Dismissed");
      let show = getCookieValue(alert.id + "Show");
      let d = new Date();
      let e = new Date(alert.expires);
      if(show === null) {
        setCookie(id+"Show", true, alert.expiration);
        show = true;
      }
      if(show && !dismissed && (d < e)) {
        makeAlert(alert);
      }
    }
  });

});

function setCookie(name, value, expiration) {
  var d = new Date(expiration);
  var expires = "expires="+ d.toUTCString();
  document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

function setDismissCookie(alert_id) {
  setCookie(alert_id + "Dismissed", true, "2100-01-01");
}

function getCookieValue(cookie_name) {
  let name = cookie_name + "=",
      cookie = decodeURIComponent(document.cookie),
      ca = cookie.split(";"),
      value = "";
  for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
          c = c.substring(1);
      }
      if (c.indexOf(name) === 0) {
          value = c.substring(name.length, c.length);
      }
  }
  switch(value) {
    case '':
      value = null;
      break;
    case 'true':
      value = true;
      break;
    case 'false':
      value = false;
      break;
    default:
      value = null;
  }
  return value;
}

function makeAlert(options) {

  function htmlDecode(input){
    var e = document.createElement('textarea');
    e.innerHTML = input;
    // handle case of empty input
    return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
  }

  let $alert = $("<div class = 'alert alert-dismissible special-alert' style = 'opacity: 85%;' role = 'alert'/>");
  $alert.prepend("<button type = 'button' class = 'close', data-dismiss='alert' onclick = \"setDismissCookie('" + options.id + "')\">&times;</button>");
  $alert.addClass('alert-'+ options.style);
  if(Object.keys(options).indexOf('title') > -1) {
    $alert.append("<h3 class = 'alert-heading'>" + htmlDecode(options.title) + "</h3>");
  }
  if(Object.keys(options).indexOf('message') > -1) {
    $alert.append(htmlDecode(options.message));
  }
  $("div#special-alerts").append($alert);

}
