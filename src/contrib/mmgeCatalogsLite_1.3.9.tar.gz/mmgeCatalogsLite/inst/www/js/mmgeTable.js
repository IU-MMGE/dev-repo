class mmgeTable {

  constructor(tableId) {
    this.id = tableId;
    this._datatable = null;
    this.jQtable = null;
    this.selectedRows = [];
    this.allCurrentRows = [];

    Shiny.addCustomMessageHandler("allCurrentRows", (message) => {
      this.allCurrentRows = message;
    });

    $(document).ready(() => {
      $(".catalog-control").on("search", (ev, data) => {
        this.draw();
      });
    });

    this.on("selection", (e, data) => {
      if(data.etype === "select") {
        this.addSelection(data.indexes);
      } else if(data.etype === "deselect") {
        this.removeSelection(data.indexes);
      }
      this.updateServer();
      this.trigger("update", {
        type: "selection",
        table: this,
        originalEvent: {
          e: e,
          data: data
        }
      });
    });

  }

  get datatable() {

    if(this._datatable !== null) {
      return this._datatable;
    } else {
      try {
        this._datatable = $("#" + this.id).find("table tbody").parent().DataTable()
          .off("draw.mmge")
          .off("user-select.mmge")
          .off("select.mmge")
          .off("deselect.mmge");

        this._datatable.mmgeTable = this;

        this._datatable.on("draw.mmge", (e, settings) => {
          this.trigger("update", {
            type: "draw",
            table: this,
            originalEvent: {
              e: e,
              settings: settings
            }
          });
        });

        this._datatable.on("user-select.mmge", function(e, dt, type, cell, originalEvent) {
          if(originalEvent.target.tagName.toLowerCase() === "button") {
            return false;
          }
        });

        this._datatable.on("select.mmge", (e, dt, type, indexes) => {
          this.trigger("selection", {
            e: e,
            dt: dt,
            type: type,
            indexes: indexes,
            etype: "select"
          });
        });

        this._datatable.on("deselect.mmge", (e, dt, type, indexes) => {
          this.trigger("selection", {
            e: e,
            dt: dt,
            type: type,
            indexes: indexes,
            etype: "deselect"
          });
        });

        return this._datatable;

      } catch(err) {
        this._datatable = null;
        console.log("ERROR WITH DATATABLE");
        console.log(err);
      }

    }

  }

  get count() {
    return this.selectedRows.length;
  }

  get stats() {
    let x = this.datatable.page.info();
    x.recordsSelected = this.selectedRows.length | 0;
    return x;
  }

  on(event, handler) {
    $(this.datatable.context[0]).on(event, handler);
  }

  trigger(event, data) {
    $(this.datatable.context[0]).trigger(event, data);
  }

  draw() {
    this.datatable.draw();
  }

  addSelection(s) {
    s = this.constructor.makeArray(s, this.datatable)
      .filter((id) => {
        return this.selectedRows.indexOf(id) === -1;
      });
    this.selectedRows = this.selectedRows.concat(s);
    return this;
  }

  removeSelection(s) {
    s = this.constructor.makeArray(s, this.datatable);
    this.selectedRows = this.selectedRows.filter(function(id) {
      return s.indexOf(id) === -1;
    });
    return this;
  }

  updateTableSelection() { // WITHOUT TRIGGERING EVENTS

    let table = this.datatable,
      selected_rows = table.rows(table.mmgeTable.selectedRows);

    selected_rows.iterator('row', (context, index) => {
      context.aoData[index]._select_selected = true;
    });

    $(table.rows().nodes()).removeClass("selected");
    $(selected_rows.nodes()).addClass("selected");

    this.trigger("selection", {
      etype: "programmatic"
    });

  }


  updateServer() {
    Shiny.onInputChange("selected_rows", this.selectedRows);
  }

  selectAll() {
    let allCur = this.allCurrentRows;
    let newCur = this.allCurrentRows.filter((x) => {
      return this.selectedRows.indexOf(x) === -1;
    });
    this.selectedRows = this.selectedRows.concat(newCur);
    this.updateTableSelection();
    this.updateServer();
  }

  selectNone() {
    this.selectedRows = this.selectedRows.filter((x) => {
      return this.allCurrentRows.indexOf(x) === -1;
    });
    this.updateTableSelection();
    this.updateServer();
  }

  selectInvert() {
    let allCur = this.allCurrentRows;
    let unselCur = this.allCurrentRows.filter((x) => {
      return this.selectedRows.indexOf(x) === -1;
    });
    let selCur = this.allCurrentRows.filter((x) => {
      return this.selectedRows.indexOf(x) > -1;
    });
    this.selectedRows = this.selectedRows.concat(unselCur);
    this.selectedRows = this.selectedRows.filter((x) => {
      return selCur.indexOf(x) === -1;
    });
    this.updateTableSelection();
    this.updateServer();

  }

  clearSelection() {
    this.selectedRows = [];
    this.updateTableSelection();
    this.updateServer();
  }

  static makeArray(x, ctlg) {
    if(x === null || x === undefined) {
      return [];
    } else {
      if(Array.isArray(x) === false) {
        x = [x];
      }
      return x
        .map(function(id) {
          if(Number.isInteger(id)) {
            return ctlg.rows(id).ids(true)[0];
          } else {
            return id;
          }
        });
    }
  }

}
