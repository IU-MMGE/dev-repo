#'@export
update_package <- function(pkg_dir = ".", increment = NULL, commit_msg = NULL) {

  pkg_dir <- "/var/miniCRAN/mmgeverse/mmgeRepo/"
  owd <- getwd()
  setwd(pkg_dir)

  withCallingHandlers(
    {
      update_description(pkg_dir, increment)
      devtools::document(pkg = pkg_dir, quiet = TRUE)
      if(is.null(commit_msg)) {
        message("\n")
        commit_msg <- readline("Enter a commit message: ")
        if(trimws(commit_msg) == "") stop("You must enter a commit message.")
      }
      repo <- git2r::repository(pkg_dir)
      git2r::add(repo = pkg_dir, path = "*")
      git2r::commit(repo = pkg_dir, message = commit_msg)
      system("git push")
    },
    error = function(e) {
      setwd(owd)
      stop(e, call. = FALSE)
    },
    finally = function(e) {
      setwd(owd)
    }
  )

  pkg_file <- devtools::build(pkg = pkg_dir, path = tempdir())

  drat::insertPackage(pkg_file)
  drat::archivePackages()

}


