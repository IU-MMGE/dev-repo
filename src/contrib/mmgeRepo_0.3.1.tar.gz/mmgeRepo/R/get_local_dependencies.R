#'@export
get_local_dependencies <- function(packages) {

  repo_dir <- file.path(getOption("repo_dir"), "repo")
  repo_url <- paste0("file://", repo_dir)

  mmge_packages <- list.dirs("/var/miniCRAN/mmgeverse", recursive = FALSE, full.names = FALSE)
  x <- as.data.frame(available.packages(repos = repo_url))

  local_deps <- packages[packages %in% mmge_packages]
  if(length(local_deps) > 0) {
    for(local_dep in local_deps) {
      local_deps <- unique(c(local_deps, get_local_dependencies(get_dependecies(local_dep))))
    }
  }

  return(local_deps)

}