#'@export
make_local_repo <- function(overwrite = FALSE, repo_dir = getOption("repo_dir"), cran_repo = 'https://ftp.ussg.iu.edu/CRAN/') {

  local_repo <- file.path(repo_dir, "repo")

  if(dir.exists(local_repo)) {
    if(overwrite == TRUE) {
      unlink(local_repo)
    } else {
      stop("Repo already exists at `", local_repo, "` and `overwrite` = FALSE", call. = FALSE)
    }
  }

  dir.create(local_repo)

  config <- yaml::read_yaml(file.path(repo_dir, "packages.yaml"))

  pkgs <- unique(config$cran)

  pkgList <- miniCRAN::pkgDep(pkgs, repos = cran_repo, type = 'source', suggests = TRUE)

  miniCRAN::makeRepo(pkgList, path = local_repo, repos = cran_repo, type = 'source')

  x <- get_local_dependencies(config$mmgeverse)

  deps <- add_local_packages(x)

  miniCRAN::addPackage(unique(not_local(deps)), path = local_repo)

}