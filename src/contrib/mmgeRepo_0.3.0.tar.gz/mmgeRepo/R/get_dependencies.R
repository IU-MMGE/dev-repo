#'@export
get_dependecies <- function(package, suggests = FALSE) {

  dependency_headers <- c("Imports:", "Depends:", "LinkingTo:")

  if(suggests) {
    dependency_headers <- c(dependency_headers, "Suggests:")
  }

  mmge_packages <- list.dirs("/var/miniCRAN/mmgeverse", recursive = FALSE, full.names = FALSE)

  dependencies <- c()

  if(package %in% mmge_packages) {

    pkg_path <- file.path(getOption('repo_dir'), "mmgeverse", package)

    pkg_desc <- readLines(file.path(pkg_path, "DESCRIPTION"))
    headers <- grep("^.*:", pkg_desc)

    for(desc_header in dependency_headers) {

      current_header <- grep(paste0("^.*", desc_header), pkg_desc)
      if(length(current_header) > 0) {
        next_header <- suppressWarnings(min(headers[headers > current_header]))
        if(is.infinite(next_header)) {
          next_header <- length(pkg_desc) + 1
        }
        pkgs <- pkg_desc[current_header:(next_header - 1)]
        pkgs <- unlist(strsplit(pkgs, ","))
        pkgs <- gsub("\\(.+\\)", "", pkgs) # Remove any requirements
        pkgs <- trimws(gsub(desc_header, "", pkgs)) # Remove the header and any whitespace
        pkgs <- pkgs[nchar(pkgs) > 0] # Remove any empty values
        pkgs <- pkgs[pkgs != "R"] # Remove "R" dependencies
        dependencies <- unique(c(dependencies, pkgs))
      }
    }

  }

  return(dependencies)

}
