#'@export
install_packages <- function(..., packages, system_install = FALSE) {

  repo_dir <- file.path(getOption("repo_dir"), "repo")
  repo_url <- paste0("file://", repo_dir)
  src_dir <- file.path(getOption('repo_dir'), "mmgeverse")

  if(missing(packages)) {
    packages <- as.character(eval(substitute(alist(...))))
  }

#  packages <- c("mmge", "dplyr", "abc", "test")

  if(length(packages) == 0) {
    warning("No packages found to install...", call. = FALSE)
    return(FALSE)
  }

  package_file <- yaml::yaml.load_file(file.path(getOption("repo_dir"), "packages.yaml"))

  mmge_packages <- list.dirs(src_dir, recursive = FALSE, full.names = FALSE)

  installed_packages <- as.data.frame(installed.packages())

  local_deps <- get_local_dependencies(packages)

  cran_packages <- as.data.frame(available.packages(repos = "https://cloud.r-project.org"))

  from_mmge <- packages[packages %in% mmge_packages]
  from_cran <- packages[packages %in% cran_packages$Package]
  from_unknown <- packages[!packages %in% from_mmge & !packages %in% from_cran]

  if(length(from_unknown) > 0) {
    warning("Could not find the following package(s) locally or on CRAN: ", paste(from_unknown, collapse = ", "), call. = FALSE)
    packages <- packages[!packages %in% from_unknown]
  }

  message("Adding local packages to local repo...")
  deps <- unique(c(from_cran, add_local_packages(local_deps)))
  deps <- deps[!deps %in% mmge_packages]

  message("Adding packages to local repo. This may take a while...")
  miniCRAN::addPackage(pkgs = deps, path = repo_dir, repos = "https://cloud.r-project.org", quiet = TRUE)

  message("Updating saved package list...")
  package_file$cran <- sort(unique(c(package_file$cran, from_cran, deps)))
  yaml::write_yaml(package_file, file = file.path(getOption("repo_dir"), "packages.yaml"))

  message("Installing requested packages...")
  install.packages(packages)

}
