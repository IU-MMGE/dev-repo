packages <- c("scheduleR2", "pymailr", "oncore2", "mmgeProtocols", "mmgeLDAP", "mmgeRepo",
              "mmgeInventory", "mmgeCatalogs", "mmgeCatalogsLite", "mmge", "IUGBAPI")

for(package in packages) {

  dir <- file.path("/var/miniCRAN/mmgeverse", package)
  print(package)
  cmd <- glue::glue("git -C '{dir}' remote set-url origin git@github.iu.edu:mmge-r/{package}.git")
  system(cmd)
  system(glue::glue("git -C '{dir}' push -u origin master"))

}

for(package in packages) {

  dir <- file.path("/var/miniCRAN/mmgeverse", package)
  print(package)

  cmd <- glue::glue("git -C '{dir}' checkout -b dev")
  system(cmd)
  system(glue::glue("git -C '{dir}' push -u origin dev"))

}
