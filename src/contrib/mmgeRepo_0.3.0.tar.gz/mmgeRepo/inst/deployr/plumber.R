#
# This is a Plumber API. You can run the API by clicking
# the 'Run API' button above.
#
# Find out more about building APIs with Plumber here:
#
#    https://www.rplumber.io/
#

library(plumber)

plumber::options_plumber(port = 3579)

key <- "Y$?Au#MC$aJnEpv~5&Vq3hX9&=<et?bQ"
url <- "https://nform.iu.edu/dev/rsc/deployr/"

#* @apiTitle Plumber Example API

#* deployment endpoint
#* @post /
function(req, res) {

  body <- req$postBody
  hash <- digest::hmac(key, body, algo = "sha1")
  gh_hash <- gsub("sha1=", "", req$HTTP_X_HUB_SIGNATURE)
  if(gh_hash != hash) {
    res$status = 403
    return("Forbidden")
  }
  bdy <- jsonlite::fromJSON(body)
  if(!"ref" %in% names(body)) {
    res$status = 404
    return("Not Found")
  }
  r <- list(
    dev = grepl("/dev$", bdy$ref),
    prod = grepl("/master$", bdy$ref),
    branch = ifelse(grepl("/dev$", bdy$ref), "dev", ifelse(grepl("/master$", bdy$ref), "master", NA)),
    repo = bdy$repository$name,
    ssh_url = bdy$repository$ssh_url,
    clone_url = bdy$repository$clone_url
  )

  if(!is.na(r$branch)) {

    if(r$branch == "dev") {
      drat_repo <- "dev-repo"
    } else {
      drat_repo <- "repo"
    }

    td <- tempdir()
    system(glue::glue("git -C '{td}' clone --branch {r$branch} {r$ssh_url}"), wait = TRUE)
    pkg_file <- devtools::build(file.path(td, r$repo))

    system(glue::glue("git -C '{td}' clone --branch gh-pages git@github.iu.edu:mmge-r/{drat_repo}.git"), wait = TRUE)

    drat::insertPackage(pkg_file, repo = file.path(td, drat_repo), commit="Update package", action='prune')

    system(glue::glue("git -C '{file.path(td, drat_repo)}' push"), wait = TRUE)

  }



  return(pkg_file)

}
