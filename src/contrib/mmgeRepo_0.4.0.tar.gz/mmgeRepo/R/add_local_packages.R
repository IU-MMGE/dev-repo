#'@export
add_local_packages <- function(pkgs) {

  deps <- c()
  src_dir <- file.path(getOption("repo_dir"), "sources")

  for(pkg in pkgs) {

    deps <- unique(c(deps, get_dependecies(pkg)))

    pkg_file <- devtools::build(file.path(getOption('repo_dir'), "mmgeverse", pkg), path = src_dir)
    x <- miniCRAN::addLocalPackage(pkgs = pkg, src_dir, file.path(getOption("repo_dir"), "repo"), quiet = TRUE)

  }

  return(invisible(deps))

}
