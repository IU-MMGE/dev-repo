local_packages <- function() {

  list.dirs(file.path(getOption('repo_dir'), "mmgeverse"), recursive = FALSE, full.names = FALSE)

}

not_local <- function(packages) {

  packages[!packages %in% local_packages()]

}