#'@export
insertPackage <- function(pkg, commit = NULL, add_all = TRUE) {

  if(dir.exists(pkg)) {
    if(is.null(commit)) {
      stop("You must provide a commit message")
    }
    if(!dir.exists(file.path(pkg, "R"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    if(!file.exists(file.path(pkg, "DESCRIPTION"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    branch <- system("git rev-parse --abbrev-ref HEAD", intern = TRUE)
    if(!branch %in% c("dev", "master")) {
      stop("You can only insert the `dev` or `master` branch. Current branch is `", branch, "`.\n\nMerge `", branch, "` with the `dev` or `master` branch and insert the result.")
    }
    if(add_all) system(glue::glue("git -C {pkg} add -A"), wait = TRUE)
    system(glue::glue("git -C {pkg} commit -m '{commit}'"), wait = TRUE)
    system(glue::glue("git -C {pkg} push"), wait = TRUE)

  } else {
    stop("`pkg` should be a directory with an R package structure.")
  }

}