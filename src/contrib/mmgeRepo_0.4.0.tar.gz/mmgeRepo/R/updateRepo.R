updateRepo <- function(message = NULL) {
  if(is.null(message)) {
    stop("You must include a message describing your update")
  }
  repodir = getOption("mmgeRepo.dir")
  if(is.null(repodir)) {
    stop("You must set the `mmgeRepo.dir` option to point to the local directory housing your drat repository")
  }
  drat::pruneRepo(getOption("mmgeRepo.dir"), remove = TRUE)
  info <- drat::getRepoInfo(getOption("mmgeRepo.dir"))
  tbl <- htmlTable::htmlTable(info)
  git2r::add(repodir, "**/*")
  git2r::commit(repodir, message = message)
  system(glue::glue("git -C {repodir} push"))

}