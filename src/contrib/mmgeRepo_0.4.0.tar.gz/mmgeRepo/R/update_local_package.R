#'@export
update_local_package <- function(package, increment = 'patch', commit_and_push = TRUE, commit_msg) {

  lib_path <- file.path(getOption('repo_dir'), "mmgeverse")

  n <- try(class(package), silent = TRUE)
  if(inherits(n, "try-error")) {
    package = as.character(eval(substitute(alist(package))))
  } else if(n == "character") {
    package <- package
  } else {
    package <- as.character(substitute(package))
  }

  fn <- file.path(lib_path, package)

  if(commit_and_push == TRUE & missing(commit_msg)) {
    if(increment == "patch") {
      commit_msg <- "small updates"
    } else {
      stop("`", increment, "` updates require a commit message.")
    }
  }

  if(dir.exists(fn)) {

    wd <- getwd()
    system(paste0("git pull"))
    setwd(fn)

    update_package_version(fn, increment)
    devtools::document(fn)

    if(commit_and_push) {
      message("Committing changes to remote repository...")
      withCallingHandlers({
        repo <- git2r::repository(fn)
        system(paste0("sudo git --git-dir=", fn ,"/.git --work-tree=", fn, " add -A"))
        system(paste0("sudo git --git-dir=", fn ,"/.git --work-tree=", fn, " commit -m '", commit_msg, "'"))
        system(paste0("git push"))
      },
      error = function(e) {
        setwd(wd)
      },
      finally = function(e) {
        setwd(wd)
      })
    }

    message("Adding updated package to local repository...")
    add_local_packages(package)

    message("Installing updated package...")
    eval(parse(text = glue::glue("install.packages('{package}')")))

  } else {
    stop("`", fn, "` not found.", call. = FALSE)
  }

}