#'@export
updatePackage <- function(pkg = ".", increment = 'patch', commit = NULL, insert = TRUE) {

  if(dir.exists(pkg)) {
    if(insert && is.null(commit)) {
      stop("You must provide a commit message")
    }
    if(!dir.exists(file.path(pkg, "R"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    if(!file.exists(file.path(pkg, "DESCRIPTION"))) {
      stop("`", pkg, "` does not appear to contain an R package")
    }
    update_package_date(pkg)
    update_package_version(pkg, increment)
    if(insert) {
      insertPackage(pkg, commit)
    }
  } else {
    stop("`pkg` should be a directory with an R package structure.")
  }

}