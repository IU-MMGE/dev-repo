update_description <- function(pkg_dir = ".", increment = NULL) {

  desc <- readLines(file.path(pkg_dir, "DESCRIPTION"))
  name <- strsplit(desc[grep("^Package", desc)], " ")[[1]][2]

  vl <- desc[grep("^Version", desc)]
  current_version <- regmatches(vl, regexec("[0-9]+\\.[0-9]+\\.[0-9]+", vl))[[1]]

  message(glue::glue("\n\nUpdating {name} {current_version}...\n\n"))

  if(is.null(increment)) {
    message("Update type:")
    message("  1: major (X.0.0)")
    message("  2: minor (0.X.0)")
    message("  3: patch (0.0.X)\n")
    update_type = as.numeric(readline("Select 1, 2, or 3: "))
    if(!update_type %in% c(1,2,3)) {
      stop(glue::glue("`{update_type}` is not an available option."), call. = FALSE)
    }
    increment <- c("major", "minor", "patch")[update_type]
  }

  update_package_version(pkg_dir, increment)
  update_package_date(pkg_dir)

  # message("\n")
  # commit_msg <- readline("Enter a commit message: ")
  # if(commit_msg == "") stop("You must enter a commit message.")

}