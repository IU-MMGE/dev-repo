#
# This is a Plumber API. You can run the API by clicking
# the 'Run API' button above.
#
# Find out more about building APIs with Plumber here:
#
#    https://www.rplumber.io/
#

library(plumber)

plumber::options_plumber(port = 3579)

key <- "Y$?Au#MC$aJnEpv~5&Vq3hX9&=<et?bQ"
url <- "https://nform.iu.edu/dev/rsc/deployr/"

#* @apiTitle Plumber Example API

#* deployment endpoint
#* @post /
function(req, res) {

  authorized <- FALSE

  try({
    hash <- digest::hmac(key, req$postBody, algo = "sha1")
    gh_hash <- gsub("sha1=", "", req$HTTP_X_HUB_SIGNATURE)
    if(gh_hash == hash) {
      authorized <- TRUE
    }
  })

  if(!authorized) {
    res$status = 403
    return("Forbidden")
  }

  body <- jsonlite::fromJSON(req$postBody)
  if(!"ref" %in% names(body)) {
    res$status = 400
    return("This endpoint only processes push hooks")
  }

  branch <- ifelse(grepl("/dev$", body$ref), "dev", ifelse(grepl("/master$", body$ref), "master", body$ref))
  name <- body$repository$name
  url <- bdy$repository$ssh_url
  commit_message <- bdy$head_commit$message
  committer <- bdy$head_commit$author$username

  if(!branch %in% c("dev", "master")) {
    res$status <- 204
    return("This endpoint only processes pushes to `dev` or `master`")
  }

  if(r$branch == "dev") {
    drat_repo <- "dev-repo"
  } else {
    drat_repo <- "repo"
  }

  td <- tempdir()
  system(glue::glue("git -C '{td}' clone --branch {branch} {url}"), wait = TRUE)
  pkg_file <- devtools::build(file.path(td, name))

  version <- try(gsub(".tar.gz$", "", gsub(paste0(r$repo, "_"), "", basename(pkg_file))))
  if(inherits(version, 'try-error')) {
    commit_msg <- glue::glue("{committer} updated {r$repo} - ({commit_message})")
  } else {
    commit_msg <- glue::glue("{committer} updated {r$repo} to version {version} - ({commit_message})")
  }

  system(glue::glue("git -C '{td}' clone --branch gh-pages git@github.iu.edu:mmge-r/{drat_repo}.git"), wait = TRUE)

  drat::insertPackage(pkg_file, repo = file.path(td, drat_repo), commit=FALSE)
  drat::pruneRepo(repo = file.path(td, drat_repo), remove = TRUE)
  system(glue::glue("git -C '{file.path(td, drat_repo)}' add -A"), wait = TRUE)
  system(glue::glue("git -C '{file.path(td, drat_repo)}' commit -m '{commit_msg}'"), wait = TRUE)
  system(glue::glue("git -C '{file.path(td, drat_repo)}' push"), wait = TRUE)

  return(commit_msg)

}
