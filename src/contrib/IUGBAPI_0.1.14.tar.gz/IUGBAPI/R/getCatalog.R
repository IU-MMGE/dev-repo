#'@export
getCatalog <- function(catalogName = "catalog", filters, api_name = NULL, envvar_name = NULL, url = NULL) {

  endpoint <- api_url(paste0("catalogs/", catalogName, ".csv"), filters, api_name = api_name, url = url)

  catalog <- getRequest(endpoint, api_name = api_name, envvar_name = envvar_name)

  if(nchar(catalog) > 0) {
    catalog <- read.csv(textConnection(catalog), stringsAsFactors = FALSE, header = TRUE)
  } else {
    catalog <- data.frame()
  }

  return(catalog)

}
