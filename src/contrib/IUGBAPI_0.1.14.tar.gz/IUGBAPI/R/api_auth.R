api_auth <- function(api_name = NULL, envvar_name = NULL) {
  token <- getAPIvalue('token')
  if(is.null(token)) {
    if(!is.null(api_name)) {
      token <- local({
        load("~/.IUGBAPI")
        if(api_name %in% names(iugbapiOptions)) {
          return(iugbapiOptions[[api_name]]$token)
        } else {
          return(NULL)
        }

      })
    }
  }
  if(is.null(token)) {
    if(!is.null(envvar_name)) {
      token <- Sys.getenv(envvar_name)
      if(token == "") {
        token = NULL
      }
    }
  }
  if(is.null(token)) {
    stop("Unable to locate a usable JWT token for this call")
  }
  httr::add_headers(Authorization = paste("JWT", token))
}
