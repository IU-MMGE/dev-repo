#'@export
postOrder <- function(order, attachments, api_name = NULL, envvar_name = NULL, url = NULL) {

  body <- list()

  if(is.character(order)) {
    if(file.exists(order)) {
      body$order <- upload_file(order)
    } else {
      stop("Could not find file: ", order)
    }
  } else if(is.list(order)) {
    body$order <- jsonlite::toJSON(order)
  } else {
    stop("Could not recognize the order format.")
  }

  if(!missing(attachments)) {
    att <- list()
    for(i in seq_along(attachments)) {
      att[i] <- upload_file(attachments[[i]])
    }
    names(att) <- rep("attachments", length(att))
    body <- c(body, att)
  }

  endpoint <- api_url("orders", api_name = api_name, url = url)

  return(postRequest(endpoint, body, encode="multipart", api_name = api_name, envvar_name = envvar_name))

}
