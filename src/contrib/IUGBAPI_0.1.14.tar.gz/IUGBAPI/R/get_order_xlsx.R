get_order_xlsx <- function(orderid, fp = "/media/R") {

  x <- getOrder(orderid)

  y <- lapply(seq(length(x)), function(i) {

    as.data.frame(x[[i]], stringsAsFactors = FALSE)

  })
  names(y) <- names(x)

  y$samples <- as.data.frame(do.call(rbind, lapply(x$samples, as.character)), stringsAsFactors = FALSE)
  names(y$samples) <- names(x$samples[[1]])

  openxlsx::write.xlsx(y, file = file.path(fp, paste0("biosend_", orderid, ".xlsx")))

}
