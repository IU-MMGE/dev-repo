#'@export
getDoc <- function(orderID, documentID, dest_file = tempfile(), api_name = NULL, envvar_name = NULL, url = NULL) {

  endpoint <- api_url(paste0("orders/", orderID, "/docs/", documentID), api_name = api_name, url = url)

  httr::GET(endpoint, api_auth(api_name = api_name, envvar_name = envvar_name), write_disk(dest_file, overwrite = TRUE))

  return(dest_file)

}
