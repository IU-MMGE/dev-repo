#'@export
getStatus <- function(orderID, api_name = NULL, envvar_name = NULL, url = NULL) {

  endpoint <- api_url(paste0("orders/", orderID, "/status.json"), api_name = api_name, url = url)

  return(getRequest(endpoint, as = "parsed", api_name = api_name, envvar_name = envvar_name)$message)

}
