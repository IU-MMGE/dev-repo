# oncore2
functions to assist in querying and shaping oncore data

