#' filter_oncore
#'
#' filter the returned results from oncore based on a series of predefined
#' criteria
#
#' \code{filter_oncore} accepts any of a number of oncore filtering functions
#' that makes filtering the results coming from oncore easy. See
#' \code{\link{filter_helpers}} for more information about individual filters
#' available.
#'
#' Like the other querying functions in oncore, the first arguement to
#' \code{filter_oncore} has to be an \code{oncoreQuery} object created by
#' \code{\link{oncore_connect}}. This allows \code{filter_oncore} to be piped
#' like the other querying functions.
#' @export
filter_oncore <- function(queryObject, ..., filters) {

  checkOncoreObject(queryObject)

  if(missing(filters)) {
    filters <- list(...)
  }

  for(filter in filters) {
    queryObject$joins <- unique(c(queryObject$joins, filter$joins))
    queryObject$conditions <- unique(c(queryObject$conditions, filter$conditions))
  }

  if("filters" %in% names(queryObject)) {
    queryObject$filters <- c(queryObject$filters, filters)
  } else {
    queryObject$filters <- filters
  }

  l <- length(filters)
  rpt("Added ", l, " filter", ifelse(l == 1, "", "s"), " to query...")

  return(queryObject)

}

filter_oncore_ <- function(queryObject, ..., filters) {

  if(missing(filters)) {
    filters <- list(...)
  }

  x <- lapply(filters, function(filter) {eval(parse(text = filter))})

  return(filter_oncore(queryObject, filters = x))

}
