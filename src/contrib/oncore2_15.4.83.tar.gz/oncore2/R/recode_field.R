#' recode_field
#'
#' Recode an oncore field based on a lookup table. An updated version of recodeField.
#'
#'@param data a dataframe that contains a field you want to recode
#'@param field_name The name of the field you want to recode
#'@param lookup_table Optional data.frame that contains lookup values
#'@param code If supplying a custom lookup_table this is the field name that contains the encoded values
#'@param value If supplying a custom lookup_table this is the field name that contains the decoded values
#'@param category When using the default lookup_table this allows you to subset the lookup_table by categories
#'
#' This function is designed to be piped and used like dplyr functions.
#'
#'@export
recode_field <- function(data, field_name, lookup_table, code = "CODE_ID",
                         value = "DESCRIPTION", category, force_recode = FALSE) {

  # Get a vector off all values in field
  if(any(grepl("|", x = data[[field_name]], fixed = TRUE))) {
    values <- unique(unlist(strsplit(unique(data[[field_name]]), "|", fixed = TRUE)))
  } else {
    values <- unique(data[[field_name]])
  }
  values <- values[!is.na(values)]

  good_lookup <- FALSE # flag for if good lookup table results found

  if(missing(lookup_table)) lookup_table <- oncore2::lookup_table()

  if(!missing(category)) {
    lookup_table <- lookup_table[lookup_table$CATEGORY %in% category, ]
  }

  lt <- lookup_table[lookup_table$CODE_ID %in% values, ]

  if(nrow(lt) > 0) {

    if(length(unique(lt$CODE_ID)) == nrow(lt)) { ## No duplicated codes
      lookup_table <- lt
      good_lookup <- TRUE
    } else {
      cats <- unique(lt$CATEGORY)
      cat_match <- sapply(cats, function(x) {
        return(all(values %in% lt[lt$CATEGORY == x, "CODE_ID"]))
      })
      if(sum(cat_match) == 1) {
        lookup_table <- lt[lt$CATEGORY == cats[cat_match], ]
        good_lookup <- TRUE
      } else if(!is.na(cat_match['EDC'])) {
        if(cat_match['EDC'] == TRUE) {
          good_lookup <- TRUE
          lookup_table <- lt[lt$CATEGORY == "EDC", ]
        }
      }
    }

    if(good_lookup == FALSE) {
      msg <- paste0("No good lookup table subset found for `", field_name, "`.")
      if(force_recode == FALSE) {
        msg <- paste0(msg, " Returning original data. Use `force_recode = TRUE` to attempt to force the recode anyway.")
      } else {
        msg <- paste0(msg, " Attempting to recode anyway.")
      }
      warning(msg, call. = FALSE)
    }

    if(good_lookup == TRUE || force_recode == TRUE) {

      max_lookup_value <- suppressWarnings(try({max(as.numeric(values), na.rm = TRUE)}, silent = TRUE))
      if(is.infinite(max_lookup_value)) max_lookup_value <- Inf

      try({
        if(max_lookup_value < 1000) {
          warning("Recoding values below 1000 may have unintended consequences.", call. = FALSE)
        }
      })

      categories <- unique(lookup_table$CATEGORY)
      if(length(categories) > 1) {
        warning("Recoding based on multiple lookup categories: ", paste(categories, collapse = ", "), call. = FALSE)
      }

      data_backup <- data
      if(length(grep("|", data[[field_name]], fixed = TRUE)) == 0) {
        data[[field_name]] <- lookup_table[match(data[[field_name]], lookup_table[, code]), value]
      } else {
        data[[field_name]][is.na(data[[field_name]])] <- ""
        for(i in seq(nrow(lookup_table))) {
          data[[field_name]] <- gsub(pattern = lookup_table[[code]][i], replacement = lookup_table[[value]][i], data[[field_name]], fixed = TRUE)
        }
      }
      data[[field_name]][is.na(data[[field_name]])] <- data_backup[[field_name]][is.na(data[[field_name]])]

    }

  }

  return(data)

}

#' recodeField
#'
#' Recode an oncore field based on a lookup table
#'
#'@param data a dataframe that contains a field you want to recode
#'@param field.name The name of the field you want to recode
#'@param lookup_table Optional data.frame that contains lookup values
#'@param code If supplying a custom lookup_table this is the field name that contains the encoded values
#'@param value If supplying a custom lookup_table this is the field name that contains the decoded values
#'@param category When using the default lookup_table this allows you to subset the lookup_table by categories
#'
#' This function is designed to be piped and used like dplyr functions. Its a copy of recode_field, left for backwards compatibility
#'
#'@export
recodeField <- recode_field
