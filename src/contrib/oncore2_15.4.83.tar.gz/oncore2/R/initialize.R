#'@export
initialize_oncore2 <- function(overwrite = TRUE) {

  # Vector of files that need to be copied to the config directory
  sys_config_files <- list.files(system.file("config_files", package = "oncore2"), pattern = "yaml$")
  dest_dir <- oncore2_config_dir
  src_dir <- system.file("config_files", package = "oncore2")
  user <- system("whoami", intern = TRUE)

  # Check that the function was run as root or by someone with sudo rights
  if(system('whoami', intern = TRUE) != "root" & !check_user_group(user, getOption('nopw_group'))) {
    msg("`initialize_oncore2` must be called by root or a user with sudo nopw privleges.", type = 'error')
  }

  # Create the config directory if it doesn't exist
  if(!dir.exists(dest_dir)) {
    msg("Attempting to create `", dest_dir, "` for configuration files...", type = 'info')
    system3("sudo mkdir ", dest_dir)
    system3("sudo chmod 774 ", dest_dir)
    msg("Success", type = 'success', indent = TRUE)
  } else {
    msg("`", dest_dir, "` already exists", type = 'info')
  }

  # Loop through the files and copy them to the config directory
  for(f in sys_config_files) {

    src_file <- file.path(src_dir, f)
    dest_file <- file.path(dest_dir, f)
    dest_exists <- file.exists(dest_file)

    if(overwrite | !dest_exists) {
      write_config_file(src_file, dest_file)
    } else if(dest_exists) {
      msg(basename(dest_file), " already exists in ", dirname(dest_file), " and `overwrite` == FALSE", type = 'warning')
    }

  }

  # Changing permissions so superusers can update oncore2
  msg("Setting permissions on ", dest_dir, " for superuser access", type = 'info')
  system(paste0("sudo chmod 665 ", file.path(dest_dir, "*")))
  system(paste0("sudo chown root:rstudio_superusers -R ", dest_dir))
  msg("Success", type = 'success', indent = TRUE)

  msg("Initial configuration for oncore2 complete.", type = 'success')
  msg("Use `oncore2::configure()` to modify configuration files in the future", type = 'info')

}

#'@export
initialize_oncore2_user <- function(overwrite = FALSE) {

  user = system("whoami", intern = TRUE)

  if(user == "root") {
    msg("`initialize_oncore2_user` cannot be run as root", type = 'error')
  }

  dest_dir <- file.path("~/.oncore2")

  if(!dir.exists(dest_dir)) {
    msg("Creating ", dest_dir, "...", type = 'info')
    dir.create(dest_dir)
    system(paste0("chown ", user, ":", user, " -R ", dest_dir))
    system(paste0("chmod 700 ", dest_dir))
    dir.create(file.path(des_dir, "queries"))
    system(paste0("chown ", user, ":", user, " -R ", file.path(des_dir, "queries")))
    system(paste0("chmod 700 ", file.path(des_dir, "queries")))
    msg("Success", type = 'success', indent = TRUE)
  }

  if(rstudioapi::isAvailable()) {
    guided <- rstudioapi::showQuestion("oncore2 initialization", "Use guided set-up?", "Yes", "No")
  } else {
    msg("RStudio isn't running. Skipping guided set-up...", type = 'warning')
    guided <- FALSE
  }

  connections <- names(get_config_file("connections", TRUE))

  credentials <- lapply(connections, function(c) {
    username <- ifelse(guided, rstudioapi::showPrompt("oncore2 initialization", paste0("Enter username for ", c, " environment:")), "<username>")
    password <- ifelse(guided, rstudioapi::askForPassword(paste0("Enter Password for ", c, " environment:")), "<password>")
    list(username = username, password = password)
  })
  names(credentials) <- connections

  verbose <- ifelse(guided, rstudioapi::showQuestion("oncore2 initialization", "Default to verbose output for queries?", "Yes", "No"), TRUE)
  save_queries <- ifelse(guided, rstudioapi::showQuestion("oncore2 initialization", "Save successful queries locally?", "Yes", "No"), TRUE)
  if(guided) {
    default_env <- ""
    while(!default_env %in% connections) {
      default_env <- rstudioapi::showPrompt("oncore2 initialization", paste0("Default Environment: [", paste(connections, collapse = "|") , "] "))
      if(!default_env %in% connections) {
        msg("Please enter a valid OnCore environment", type = 'warning')
      }
    }
  } else {
    default_env <- connections[1]
  }

  if(guided) {
    msg("Guided set-up complete", type = "info")
  }

  msg("Attempting to generate user-specific configuration file...", type = 'info')
  com <- paste0("## oncore2 user configuration file for ", user, " ##")
  x <- paste(rep("#", times = nchar(com)), collapse = "")
  settings <- paste(
    x,com,x," ",
    yaml::as.yaml(list(
      credentials = credentials,
      verbose = verbose,
      save_queries = save_queries,
      env = default_env
    )), sep = "\n"
  )

  settings_file_path <- file.path(dest_dir, 'user_settings.yaml')
  settings_file <- file(settings_file_path)

  writeLines(settings, settings_file)
  system(paste0("chmod 600 ", settings_file))

  msg("`", settings_file_path, "` created for ", user, type = 'info')
  close(settings_file)

  msg("Success", type = "success", indent = TRUE)

  if(rstudioapi::isAvailable()) {
    open_file <- rstudioapi::showQuestion("oncore2 initialization", "Open settings file for editing?", "Yes", "No")
    if(open_file) {
      rstudioapi::navigateToFile(settings_file_path)
    }
  } else {
    open_file <- FALSE
  }

  if(!guided & !open_file) {
    msg("`", settings_file_path, "` has beed created. Please update with correct user credentials for OnCore", type = 'success')
  } else {
    msg("User configuration for oncore2 is complete", type = 'success')
  }

}
