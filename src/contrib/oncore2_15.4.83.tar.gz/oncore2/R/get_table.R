#'Retrieve a table or view from Oncore
#'
#'Returns the specified table or view from OnCore as a data.frame
#'
#'@param table_name The name of the table/view
#'@param env The OnCore environment to retrieve the table from
#'@param connection_type Connect to OnCore through JDBC or ODBC
#'
#'@export
get_table <- function(table_name, env = NULL, connection_type = NULL) {

  config <- get_config(get_args(environment(), 'table_name'))

  sql <- glue::glue("SELECT * FROM {config$connection$schema}.{table_name}")

  return(query_oncore(sql, config = config))

}
