#
# library(shiny)
# #library(miniUI)
#
# oncore2Addin <- function() {
#
#   ui <- miniPage(
#     gadgetTitleBar("OnCore Query Builder"),
#     miniContentPanel(
#       tags$h2("Hello World")
#     )
#   )
#
#   server <- function(input, output, session) {
#
#     observeEvent(input$done, {stopApp()})
#
#   }
#
#   viewer <- paneViewer(500)
#   runGadget(ui, server, viewer = viewer)
#
# }
#
# #oncore2Addin()
