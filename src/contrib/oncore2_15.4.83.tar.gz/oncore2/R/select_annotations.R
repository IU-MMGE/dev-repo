#' select_annotations
#'
#' Select annotations to include in your query
#'
#' As with all oncore2 query functions, you must provide an object of type
#' \code{oncoreQuery} as the first argument. \code{select_annotations} will
#' modify this object and return the updated version so that chaining can be
#' performed.
#'
#' \code{select_annotations} cannot use non-standard evalution because of the
#' nature of the annotation names, therefore you must enclose each annotation in
#' quotes. You should provide names of annotations in the
#' \code{annotations_list} data object that is part of this package.
#'
#' @note You can chain multiple \code{select_annotations} functions together.
#'   Each time the new call will add to the existing object.
#'
#' @export
select_annotations <- function(queryObject, ..., type = c("SPECIMEN", "CASE"), .dots) {

  checkOncoreObject(queryObject)

  # Get Annotation Names to add
  annotations <- list(...)
  annotations <- unlist(annotations)
  if(!missing(.dots)) {
    annotations <- unique(c(annotations, .dots))
  }
  annotations <- lapply(annotations, function(x) x)
  beginning_length <- nrow(queryObject$annotations)
  if(is.null(beginning_length)) beginning_length = 0

  al <- annotation_list()[annotation_list()$ANNOTATION_TYPE %in% type, ]

  annots <- al[al$ANNOTATION %in% annotations, ]

  if(nrow(annots) != length(annotations)) {
    msg <- paste("The following annotation(s) could not be identified:\n\t",
                 paste(annotations[!annotations %in% annots$ANNOTATION], collapse = ",\t\n"))
    handleError(queryObject, msg)
  }

  queryObject$annotations <- unique(rbind(queryObject$annotations, annots))

  if("SPECIMEN" %in% annots$ANNOTATION_TYPE) {
    queryObject$joins <- unique(c(queryObject$joins, "SV_BSM_SPECIMEN"))
#    queryObject$selects <- queryObject$selects[!grepl("SPECIMEN_NO", queryObject$selects$COLUMN_NAME, fixed = TRUE), ]
  }

  if("CASE" %in% annots$ANNOTATION_TYPE) {
    queryObject$joins <- unique(c(queryObject$joins, "SV_BSM_CASE"))
#    queryObject$selects <- queryObject$selects[!grepl("CASE_NO", queryObject$selects$COLUMN_NAME, fixed = TRUE), ]
  }

  l <- (nrow(queryObject$annotations) - beginning_length)
  rpt("Added ", l, " annotation", ifelse(l == 1, "", "s"), " to query...")

  return(queryObject)

}
