#' @rdname filter_helpers
#' @name filter_helpers
#' @title Filter Helpers
#'
#' @description These functions should be used within
#'   \code{\link{filter_oncore}} to adding filtering criteria to the resulting
#'   oncore query.
#'
#' @export
specimen_status <- function(...) {
  filter <- list()
  filter$joins <- c("BSMS_PCS_SPECIMEN")
  filter$field <- "SPECIMEN_STATUS"
  filter$conditions <- paste0("BSMS_PCS_SPECIMEN.SPECIMEN_STATUS IN (",
                             paste("'", list(...), "'",
                                   sep = "", collapse = ","), ")"
  )
  attr(filter, "field") <- filter$field
  attr(filter, "values") <- list(...)
  return(add_filter_class(filter))
}

#'@export
mmge_protocols <- function() {
  filter <- list()
  filter$joins <- c("SV_PROTOCOL")
  filter$field <- "PROTOCOL_NO"
  filter$conditions <- "SV_PROTOCOL.PROTOCOL_NO IN (SELECT distinct P.PROTOCOL_NO
from    IUCTSI_ONCORE_PROD.ONC_PCL_MANAGEMENT_GROUP M,
        IUCTSI_ONCORE_PROD.SV_ACTIVE_PROTOCOLS P,
        IUCTSI_ONCORE_PROD.ONC_MANAGEMENT_GROUP G
where  G.NAME in ('MMGE- Hereditary Genomics', 'MMGE-CC- Hereditary Genomics')
        and P.PROTOCOL_ID = M.PROTOCOL_ID
        and G.ONC_MANAGEMENT_GROUP_ID = M.RESEARCH_MANAGEMENT_GROUP_ID
)"
  return(add_filter_class(filter))
}

#' @export
reason_destroyed <- function(...) {
 filter <- list()
 filter$joins <- c("BSMS_PCS_SPECIMEN")
 filter$field <- "REASON_DESTROYED"
 filter$conditions <- paste0("NVL(BSMS_PCS_SPECIMEN.REASON_DESTROYED, -1) IN (",
                             paste(encodeField(list(...)),
                                   sep = "", collapse =", "), ")"
 )
 attr(filter, "field") <- filter$field
 attr(filter, "values") <- list(...)
 return(add_filter_class(filter))
}

#' @rdname filter_helpers
#' @export
protocol <- function(...) {

  p <- paste(unlist(list(...)), collapse = "|")
  filter <- list()
  filter$joins <- c("SV_PROTOCOL")
  filter$field <- "PROTOCOL_NO"

  filter$conditions <- paste0("REGEXP_LIKE(SV_PROTOCOL.PROTOCOL_NO, '", p, "')")
  attr(filter, "field") <- filter$field
  attr(filter, "values") <- list(...)
  return(add_filter_class(filter))

}

#' @rdname generic_filter_helpers
#' @name generic_filter_helpers
#' @title Generic Filter Helpers
#'
#' @description These functions provide low level access to filtering the OnCore
#'   database.
#' @export
date_filter <- function(field, start.date, end.date, format = "MM/DD/YYYY") {

  d <- paste0("to_date(", field, ", '", format,"')")

  if(!missing(start.date)) {
    if(class(start.date) != "Date") {
      start.date <- as.Date(start.date, "%Y-%m-%d")
    }
    start.date <- paste0("to_date('", format(start.date, "%Y-%m-%d"), "', 'YYYY-MM-DD')")
  }

  if(!missing(end.date)) {
    if(class(end.date) != "Date") {
      end.date <- as.Date(end.date, "%Y-%m-%d")
    }
    end.date <- paste0("to_date('", format(end.date, "%Y-%m-%d"), "', 'YYYY-MM-DD')")
  }

  filter <- list()
  filter$fields <- strsplit(field, ".", fixed = TRUE)[[1]][1]

  if(!missing(start.date) & !missing(end.date)) {
    filter$conditions <- paste0(d, " between ", start.date, " and ", end.date)
  } else if(!missing(start.date)) {
    filter$conditions <- paste0(d, " >= ", start.date)
  } else if(!missing(end.date)) {
    filter$conditions <- paste0(d, " <= ", end.date)
  }

  filter$field <- gsub("^.*\\.", "", field)

  return(add_filter_class(filter))

}

#'@export
accession_date <- function(start.date, end.date) {

  date_filter("SV_BSM_SPECIMEN.ACCESSION_DATE", start.date, end.date)

}

#'@export
procedure_date <- function(start.date, end.date) {

  date_filter("SV_BSM_CASE.PROCEDURE_DATE", start.date, end.date)

}

#'@export
parents_only <- function() {

  filter <- list()
  filter$fields <- c("SV_BSM_SPECIMEN")
  filter$conditions <- paste0("SV_BSM_SPECIMEN.PARENT_SPECIMEN_ID IS NULL")
  filter$field <- "PARENT_SPECIMEN_ID"
  return(add_filter_class(filter))

}

#' @rdname filter_helpers
#' @export
specimen_type <- function(..., .dots) {

  if(missing(.dots)) .dots = list(...)

  filter_text(field = "SPECIMEN_TYPE", table = "SV_BSM_SPECIMEN",
              encode = FALSE, .dots = .dots)

}

#' @rdname filter_helpers
#' @export
collection_group <- function(..., .dots) {

  if(missing(.dots)) .dots = list(...)

  filter_text(field = "COLLECTION_GROUP", table = "BSMS_PCS_SPECIMEN",
              encode = TRUE, .dots = .dots)

}

#' @rdname filter_helpers
#' @export
arm_code <- function(..., .dots) {

  if(missing(.dots)) .dots = list(...)

  filter_text(field = "ARM_CODE", table = "SV_SUB_TREATMENT", encode = FALSE, .dots = .dots)

}

#' @rdname filter_helpers
#' @export
value_in <- function(field_name, values) {

  if(grepl("\\.", field_name)) {
    table <- gsub("\\..+$", "", field_name)
    field <- gsub("^.*\\.", "", field_name)
  } else {
    table <- try(field_list()$TABLE_NAME[field_list()$COLUMN_NAME == field_name][1], silent = TRUE)
    if(inherits(table, "try-error")) {
      stop("Could not find a table that contains: ", field_name)
    } else {
      warning("Joining to `", table, "` for `", field_name, "`.", call. = FALSE)
    }
    field <- field_name
  }

  filter <- list(joins = c(table))

  v <- paste0("('", paste(values, collapse = "', '"), "')")

  filter$conditions <- paste0(field_name, " IN ", v)
  filter$field <- gsub("^.*\\.", "", field)

  return(add_filter_class(filter))

}

#' @rdname filter_helpers
#' @export
value_contains <- function(table, field_name, regex) {
  filter <- list(
    joins = c(table)
  )
  field = gsub("^.*\\.", "", field_name)
  conditions <- glue::glue("REGEXP_LIKE({table}.{field}, '{regex}')")
  filter$field <- field
  filter$conditions <- conditions
  return(add_filter_class(filter))
}

#'@export
specimen_comments <- function(comment) {

  value_contains("SV_BSM_SPECIMEN", "SPECIMEN_COMMENTS", comment)

}

#'@export
request_list <- function(requestID) {

  filter <- list(joins = c("SV_BSM_SPECIMEN"))

  v <- paste0("SELECT PCS_SPECIMEN_ID FROM ONCORE.SV_BSM_REQUEST_SPECIMENS WHERE SPECIMEN_REQUEST_ID = ", requestID)

  filter$conditions <- paste0("PCS_SPECIMEN_ID IN (", v, ")")

  return(add_filter_class(filter))

}

#' @rdname generic_filter_helpers
#' @export
filter_text <- function(..., field, table, encode = FALSE, .dots){

  if(missing(.dots)) .dots = list(...);

  filter <- list()
  filter$joins <- c(table)
  table_field <- paste(table, field, sep = ".")

  if(encode){

    filter$conditions <- paste0("NVL(", table_field, ", -1) IN ('",
                                paste(encodeField(.dots, category = "SPECIMEN_COLLECTION_GROUP"),
                                      sep = "", collapse ="', '"), "')"
    )

  }else{

    p <- paste(.dots, collapse = "|")
    filter$conditions <- paste0("REGEXP_LIKE(", table_field, ", '", p, "')")

  }

  filter$field <- gsub("^.*\\.", "", field)

  return(add_filter_class(filter))

}

#'@export
specimen_lookup <- function(specimen_nos) {

  filter <- list(joins = "SV_BSM_SPECIMEN")

  v <- paste(specimen_nos, collapse = "|^")
  v <- paste0("'^", v, "'")

  filter$conditions <- paste0("REGEXP_LIKE(SV_BSM_SPECIMEN.SPECIMEN_NO, ", v,")")

  filter$field <- "SPECIMEN_NO"

  return(add_filter_class(filter))

}

#'@export
not <- function(filter) {
  filter$conditions <- paste0("NOT (", filter$conditions, ")")
  attr(filter, "not") <- TRUE
  return(add_filter_class(filter))
}

#'@export
or <- function(...) {
  l <- list(...)
  filter <- list()
  filter$joins <- unique(sapply(l, function(f) {
    f['joins']
  }))
  filter$conditions <- paste0("(", paste(sapply(l, function(f) {
    f['conditions']
  }), collapse = " OR "), ")")
  return(add_filter_class(filter))
}

#'@export
and <- function(...) {
  paste(list(...), collapse = " AND ")
}
