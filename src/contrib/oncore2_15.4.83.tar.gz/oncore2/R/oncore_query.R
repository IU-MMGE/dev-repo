#'@export
oncore_query <- function(selects, filters, ..., .args) {

  if(missing(.args)) {
    .args = get_args(environment())
    .args <- .args[!names(.args) %in% c("selects", "filters")]
  }

  if(length(.args) == 0) {
    .args = NULL
  }

  q <- oncore_connect(.args = .args)

  s <- selects

  fields <- s[s %in% field_list()$COLUMN_NAME]
  s <- s[!s %in% fields]
  annotations <- s[s %in% annotation_list()$ANNOTATION]
  s <- s[!s %in% annotations]

  if(length(s) > 0) {

    tmp <- strsplit(s[grepl("\\.", s)], ".", fixed = TRUE)
    tmp <- tmp[unlist(sapply(tmp, function(x) {
      sum(field_list()$TABLE_NAME == x[1] & field_list()$COLUMN_NAME == x[2]) > 0
    }))]

    fields <- c(fields, sapply(tmp, function(x) paste(x, collapse = ".")))
    s <- s[!s %in% fields]

  }

  if(length(s) > 0) {
    stop("Didn't recognize all selects as valid oncore data fields.")
  }

  if(length(fields) > 0) {
    q <- select_fields_(q, .dots = fields)
  }

  if(length(annotations) > 0) {
    q <- select_annotations(q, .dots = annotations)
  }

  if(!missing(filters)) {
    if(length(filters) > 0) {
      if(inherits(filters, "oncore_filter")) {
        filters <- list(filters)
      }
      q <- filter_oncore(q, filters = filters)
    }
  }

  q <- execute_query(q, .args = .args)

  return(q)

}
