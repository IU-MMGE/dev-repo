# Ensures that the object provided is appropriate for chaining
checkOncoreObject <- function(queryObject) {

  if(class(queryObject) != "oncoreQuery") {
    stop("You must provide an oncoreQuery object.")
  } else {
    return(TRUE)
  }

}

# Non-standard Evaluation shortcut
nse <- function(...) {
  as.character(eval(substitute(alist(...))))
}

# Convert request names to a standard format
standard_names <- function(names) {
  names <- toupper(names)
  names <- gsub(" ", "_", names, fixed = TRUE)
  names <- gsub("'|\\(|\\)", "", names)
  names <- make.names(names)
  return(names)
}

handleError <- function(queryObject, msg) {

  msg(msg, type = queryObject$error)

}

# Helper function to convert values to their encoded values for filter functions.
encodeField <- function(values, lookup.table, code = "CODE_ID", value = "DESCRIPTION", category) {
  if(missing(lookup.table)) lookup.table <- lookup_table()

  if(!missing(category)) {
    lookup.table <- lookup.table[lookup.table$CATEGORY == category, ]
  }

  lookup.table[match(values, lookup.table[, value]), code]

}
