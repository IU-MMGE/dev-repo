#' Set your oncore username and password
#'
#' Running this function will prompt you for your oncore username and oncore
#' password. It will then set the environment variables neccesary to use the
#' oncore2 package.
#'
#' @export
set_oncore_credentials <- function() {

  username <- readline("Username:")
  password <- readline("Password:")

  system(sprintf("echo 'export ONCORE_USER=%s' >> ~/.bashrc", username))
  system(sprintf("echo 'export ONCORE_PW=%s' >> ~/.bashrc", password))

  message("Please restart your R session for variables to take effect.")

}
