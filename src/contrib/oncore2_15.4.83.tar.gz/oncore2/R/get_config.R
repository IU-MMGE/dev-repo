get_config <- function(args = NULL) {

  config <- utils::modifyList(get_config_file('defaults', TRUE), get_config_file("user_settings"))
  config <- utils::modifyList(config, list(credentials = get_config_file('connections', TRUE)))
  if(!is.null(args)) config <- utils::modifyList(config, args)
  config$connection <- config$credentials[[config$env]]
  config$credentials <- NULL

  Sys.setenv("oncore2_verbose" = config$verbose)

  return(config)

}

get_args <- function(envir = environment(), .exclude = c()) {
  x <- Filter(Negate(is.null), as.list(envir))
  x <- x[!names(x) %in% .exclude]
  return(x)
}
