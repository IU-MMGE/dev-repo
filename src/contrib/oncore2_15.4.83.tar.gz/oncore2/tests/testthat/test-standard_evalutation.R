context("Test that standard evaluation and non-standard evaluation give the same results")

query_non_standard <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields(PROTOCOL_NO, SV_BSM_SPECIMEN.SPECIMEN_TYPE,
                SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE) %>%
  filter_oncore(protocol("PPMI"), specimen_type("Serum")) %>%
  execute_query()

query_standard <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields_("PROTOCOL_NO", "SV_BSM_SPECIMEN.SPECIMEN_TYPE",
                "SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE") %>%
  filter_oncore(protocol("PPMI"), specimen_type("Serum")) %>%
  execute_query()

query_standard_vector <- oncore_connect("nrbyers", "hump15day", verbose = FALSE) %>%
  select_fields_(c("PROTOCOL_NO", "SV_BSM_SPECIMEN.SPECIMEN_TYPE",
                "SV_BSM_SPECIMEN.SPECIMEN_BAR_CODE")) %>%
  filter_oncore(protocol("PPMI"), specimen_type("Serum")) %>%
  execute_query()

test_that("standard and nonstandard evaluation give the same result with
          select_fields and select_fields_", {
  expect_equal(query_non_standard, query_standard)
  expect_equal(query_non_standard, query_standard_vector)
})
